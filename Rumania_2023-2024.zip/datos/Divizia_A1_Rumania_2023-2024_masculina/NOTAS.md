# Divizia A1 rumana masculina 2023-24: notas del dataset

Resumen y problemas específicos de esta temporada. La estructura de las tablas, el diccionario de
columnas y el origen de los datos están en el [README principal](../../README.md).

> **Muestra, no la liga completa.** Son 56 partidos de una liga de 12 equipos. CSM Constanta está en
> 23 y CS Stiinta Explorari Baia Mare en 14; Timisoara, Unirea Dej y Corona Brasov aparecen en 2 o 3.

## Resumen

| | 2023-24 |
|---|---|
| Archivos / partidos distintos | 63 archivos; 4 excluidos (temporada 2022-23) y 3 duplicados: 56 partidos |
| Acciones | 50.912 (53.709 con los duplicados) |
| Competiciones (`tipo_competicion`) | **Divizia A1** 49, **Cupa României** 6 y **Champions League** 1 (Arcada Galati 3-2 Lvi Praha, 14/12/2023, grupo E) |
| Fechas | 14/10/2023 → 27/04/2024 |
| Liga regular (Faza I) | 43 de 132 partidos (14/10/2023 → 09/03/2024); 13 cruces con ida y vuelta |
| Fase final | 6 partidos desde el 22/03/2024 (playoffs; `fase_original` dice "Play-Off" en dos de ellos). `tipo_competicion` sigue siendo `Divizia A1`: sepárenlos por fecha |
| Equipos | CSM Constanta, CS Stiinta Explorari Baia Mare, CS Dinamo Bucuresti, CS Rapid Bucuresti, SCM Zalau, CSA Steaua Bucuresti, SCMU Craiova, CSM Arcada Galati, CS U Cluj, CSM Corona Brasov, CSU Universitatea de Vest Timisoara, CS Unirea Dej (y Praha en la Champions) |
| Scouters | VolleyMetrics (13 archivos) y los analistas de los clubes: M.M. (Constanta, 10), Kermo Basov (Zalau, 6), PM (Dinamo, 5), Rolly (Baia Mare, 5), Marciu Laurentiu (Craiova, 4)…; 1 archivo de Betovoley |
| Acciones con coordenadas | 27 % |
| Rol de los jugadores | 88 % de las acciones |
| Jugadores (nombres distintos → unificados) | 258 → 219 |

Es scout real. En los 59 archivos, el marcador de cada set reconstruido desde el scout coincide con
la cabecera y todos los partidos están completos. Indicadores generales: side-out 57,9 %, eficiencia
de ataque 0,298, 5,49 acciones por rally y 0,55 códigos verdes por rally.

## Advertencias importantes

- **"Home"/"Away" en `fase_original` no es la localía.** Los analistas rumanos escriben "Home - Faza I"
  o "Away - Faza I" (y "Hom01"/"Awa01" en el nombre del archivo), pero "Away" marca el partido de
  **vuelta** (retur), no que su equipo jugara de visitante. Lo comprobamos con los cruces que tienen
  ida y vuelta: en los 43 partidos de la Faza I, el local de la cabecera nunca repite cancha contra
  el mismo rival, y en las copas cada vuelta se jugó en la cancha del equipo que había sido visitante
  en la ida. No usen esa columna para separar local y visitante.
- **Local y visitante: `local_real.csv`.** La cabecera es correcta en 55 de los 56 partidos. La
  excepción es Zalau–Steaua del 27/04/2024 (playoff por el 5.º–8.º puesto): el archivo dice
  Bucharest, así que el local real es Steaua. Para que sea igual que en Italia y Alemania, está el
  archivo `local_real.csv` con las mismas columnas.
- **4 archivos excluidos** (`errores.csv`): partidos de VolleyMetrics de la temporada 2022-23
  (Rapid contra Stiinta Bucuresti, Steaua y Suceava, entre el 15/10/2022 y el 04/02/2023). Stiinta
  Bucuresti y Suceava no aparecen en ningún otro archivo de 2023-24.
- **Fechas mezcladas.** Cada analista escribe la fecha a su manera, y algunos cambian de formato
  entre un archivo y otro (Constanta usa día/mes y mes/día). Se corrigieron 14 fechas
  (`partidos.fecha_corregida`). Una sigue en duda: Steaua–Dinamo de vuelta, con cabecera "03/02/2024",
  quedó el 3 de febrero; también podría ser el 2 de marzo (los dos son sábados de la vuelta).
- **Duplicados.** Stiinta–Constanta del 23/10, Constanta–Dinamo del 10/02 y Rapid–Constanta del
  22/03 vinieron en una versión del club y otra de VolleyMetrics; queda como principal la de más
  acciones (`es_principal`).
- **Nombres de equipo.** Se unificaron variantes ("ARCADA GALATI 23/24", "CSM Arcade Galati" →
  CSM Arcada Galati; "CS ""U"" Cluj" → CS U Cluj; "CSA Steaua BUCURESTI" → CSA Steaua Bucuresti).
  Lvi Praha queda como "Praha", el mismo nombre que en los datasets de la Extraliga checa.
- **Scouter escrito de varias formas** ("M.M"/"M.M.", "buldur"/"BULDUR", "Cosma Rares-Vasile"/"Cosma
  Rares Vasile"). Normalícenlo antes de agrupar por `scouter`.
- **1 línea descartada** (`errores.csv`) con un código mal escrito.

## Jugadores para revisar

En `jugadores_unificados.csv` hay 13 filas con `revisar = True`:

- **CS Rapid Bucuresti**: Rebrisorean Ionut aparece con 4 números, y "CIUBOTARU MARIAN" y "CIUBOTARU
  MARIAN ALEXANDRU" quedaron como dos jugadores con números cruzados (seguramente son dos personas
  distintas, pero revisen).
- **Jugadores en dos equipos**: Arroyo Santiago Javier (Dinamo y Rapid), Bartha Cristian Andrei (Rapid
  y Zalau), Halilovic Rusmir (Constanta y Corona Brasov), Lupu Stefan (Corona Brasov y Craiova). Pueden
  ser pases a mitad de temporada o planteles mal cargados.
- Nombres en distinto orden ("MESQUITA CAMPOS MATHAUS WOJTYLLA" / "WOJTYLLA MATHAUS MESQUITA"): se
  unificaron, pero conviene revisar los números (2 y 4).
