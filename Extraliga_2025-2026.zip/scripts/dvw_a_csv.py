#!/usr/bin/env python3
"""
dvw_a_csv.py — Convierte una carpeta (o un .zip) de archivos DataVolley (.dvw)
en tablas CSV listas para pandas.

Uso:
    python dvw_a_csv.py ENTRADA SALIDA
        ENTRADA: carpeta con .dvw (busca recursivamente) o archivo .zip
        SALIDA:  carpeta donde se escriben los CSV

Genera:
    acciones.csv.gz  una fila por acción de scout (todos los partidos), CSV comprimido
    partidos.csv   una fila por archivo/partido
    sets.csv       una fila por set
    jugadores.csv  una fila por jugador y partido (con jugador_uid unificado)
    jugadores_unificados.csv  un jugador por fila, con las variantes de nombre agrupadas
    errores.csv    líneas del scout que no se pudieron interpretar

Solo usa la biblioteca estándar + pandas.
"""
import re
import sys
import zipfile
import hashlib
import unicodedata
from datetime import date, datetime
from pathlib import Path

import pandas as pd

# ---------------------------------------------------------------------------
# Diccionarios de códigos (convención estándar de DataVolley 4).
# OJO: cada scouter puede redefinir tipos/evaluaciones; ver README.
# ---------------------------------------------------------------------------
FUNDAMENTOS = {
    "S": "Saque", "R": "Recepción", "A": "Ataque", "B": "Bloqueo",
    "D": "Defensa", "E": "Armado", "F": "Free ball", "&": "Código verde",
}

TIPO_SAQUE = {
    "H": "Flotado", "M": "Salto flotado", "Q": "Salto potente",
    "T": "Topspin", "N": "Híbrido", "O": "Otro", "U": "Otro",
}
TIPO_TEMPO = {
    "H": "Alta", "M": "Media", "Q": "Rápida", "T": "Tensa",
    "U": "Súper", "F": "Veloz", "N": "Deslizada (slide)", "O": "Otra",
}

EVALUACION = {
    "S": {"#": "Ace", "+": "Positivo (rival ataca con dificultad)",
          "!": "OK (rival sin primer tiempo)", "-": "Negativo (rival ataca cómodo)",
          "/": "Positivo (rival no puede atacar)", "=": "Error"},
    "R": {"#": "Perfecta", "+": "Positiva", "!": "OK (sin primer tiempo)",
          "-": "Negativa (ataque limitado)", "/": "Mala (sin ataque / devuelta)",
          "=": "Error"},
    "A": {"#": "Punto", "+": "Positivo", "!": "Bloqueado para reataque",
          "-": "Negativo (defendido fácil)", "/": "Bloqueado (punto rival)",
          "=": "Error"},
    "B": {"#": "Punto", "+": "Positivo", "!": "Pobre (rival puede reatacar)",
          "-": "Negativo (rival defiende cómodo)", "/": "Invasión",
          "=": "Error"},
    "D": {"#": "Perfecta", "+": "Positiva", "!": "OK (sin primer tiempo)",
          "-": "Negativa (sin ataque estructurado)", "/": "Pasa directo al campo rival",
          "=": "Error"},
    "E": {"#": "Perfecto", "+": "Positivo", "!": "OK", "-": "Negativo",
          "/": "Malo", "=": "Error"},
    "F": {"#": "Perfecta", "+": "Positiva", "!": "OK", "-": "Negativa",
          "/": "Pasa directo al campo rival", "=": "Error"},
    "&": {"#": "Punto para el equipo", "=": "Error / punto para el rival"},
}

SUBTIPO_ATAQUE = {"H": "Potente", "P": "Colocado (roll)", "T": "Toque (tip)"}

ROLES = {"1": "Líbero", "2": "Punta", "3": "Opuesto", "4": "Central", "5": "Armador"}

FASE_ATAQUE_RAW = {"r": "Tras recepción", "p": "Transición", "s": "Otra (s)"}
FASE_PUNTO_RAW = {"s": "Side-out", "p": "Break point"}

# Normalización de nombres de equipos (los scouters los escriben distinto).
# Clave: texto sin tildes en minúscula que aparece en el nombre original.
EQUIPOS_STD = [
    ("upcn", "UPCN San Juan"),
    ("ciudad de buenos aires", "Ciudad Vóley"),
    ("ciudad voley", "Ciudad Vóley"),
    ("policial", "Policial de Formosa"),
    ("monteros", "Monteros Vóley"),
    ("river", "River Plate"),
    ("obras sanitarias de san juan", "Obras de San Juan"),
    ("obras sanitarias s.j", "Obras de San Juan"),   # Obras Sanitarias de San Juan
    ("obras sanitarias sj", "Obras de San Juan"),
    ("obras sanitarias", "Obras Sanitarias"),         # Obras Sanitarias de la Nación (Bs. As.)
    ("obras", "Obras de San Juan"),
    ("once unidos", "Once Unidos"),
    ("defensores de banfield", "Defensores de Banfield"),
    ("boca", "Boca Juniors"),
    ("san lorenzo", "San Lorenzo"),
    ("tucuman", "Tucumán de Gimnasia"),
    ("chile", "Chile (selección)"),
    ("farma conde", "Farma Conde São José"),
    ("union vecinal de trinidad", "UVT San Juan"),
    ("amuvoca", "AMUVOCA"),
    ("paracao", "Gross Paracao"),
    ("cordoba voley", "Córdoba Vóley"),
    ("sada cruzeiro u19", "Sada Cruzeiro U19"),
    ("sada cruzeiro", "Sada Cruzeiro"),
    ("gigantes del sur", "Gigantes del Sur"),
    ("ateneo catamarca", "Ateneo Catamarca"),
    ("bolivar", "Bolívar"),
    ("puerto san martin", "Puerto San Martín"),
    ("puerto general san", "Puerto San Martín"),
    ("lomas voley", "Lomas Vóley"),
    ("peerless", "Peerless"),
    ("peeeless", "Peerless"),
    ("monte claros", "Montes Claros"),
    ("montes claros", "Montes Claros"),
    ("thomas morus", "Thomas Morus"),
    ("obras udap", "Obras de San Juan"),
    ("fiat minas", "Fiat Minas"),
    ("olympic", "Olympic"),
    ("carlos pellegrini", "Instituto Carlos Pellegrini"),
    ("regatas lima", "Regatas Lima"),
    ("taubate", "Taubaté"),
    ("libertad burgi", "Libertad Burgi Vóley"),
    ("untref", "UNTREF Vóley"),
    ("caramuru", "Caramuru Vôlei"),
    ("sesc", "SESC RJ"),
    ("argentina sub 21", "Argentina U21"),
    ("argentina sub-21", "Argentina U21"),
    ("argentina menor", "Argentina U19"),
    ("seleccion menor", "Argentina U19"),
    ("alianza jesus maria", "Alianza Jesús María"),
    ("alianza de jesus maria", "Alianza Jesús María"),
    ("deportivo moron", "Deportivo Morón"),
    ("psm voley", "Puerto San Martín"),
    ("libertad de san jeronimo", "Libertad de San Jerónimo Norte"),
    ("uvt", "UVT San Juan"),
    ("brasil u21", "Brasil U21"),
    ("botafogo", "Botafogo"),
    ("sao bernardo", "São Bernardo"),
    ("sesi", "SESI-SP"),
    ("hacoaj", "Club Náutico Hacoaj"),
    ("linares", "Linares"),
    ("la union de formosa", "La Unión de Formosa"),
    ("la union formosa", "La Unión de Formosa"),
    ("pilar voley", "Pilar Vóley"),
    ("pto san martin", "Puerto San Martín"),
    ("tres de febrero", "UNTREF Vóley"),
    ("lomas de zamora", "Lomas Vóley"),
    ("sarmiento santana", "Sarmiento Santana Textiles (Chaco)"),
    ("sarmiento voley", "Sarmiento Santana Textiles (Chaco)"),   # mismo club (Chaco), antes del patrocinio
    ("chubut", "Chubut Vóley"),
    ("sonder", "Rosario Sonder"),
    ("tigre voley", "Tigre Vóley"),
    ("villa maria", "Villa María Vóley"),
    ("pelegrini", "Instituto Carlos Pellegrini"),
    ("pellegrini", "Instituto Carlos Pellegrini"),
    ("pescadores", "Pescadores"),
    ("bella vista", "Bella Vista"),
    ("buenos aires unidos", "Buenos Aires Unidos"),
    ("bs as unidos", "Buenos Aires Unidos"),
    ("catamarca voley", "Catamarca Vóley"),
    ("jujuy voley", "Jujuy Vóley"),
    ("olimpo", "Olimpo de Bahía Blanca"),
    ("azul voley", "Azul Vóley (Tandil)"),
    ("azul casino", "Azul Vóley (Tandil)"),
    ("banco industrial", "Azul Vóley (Tandil)"),   # patrocinio de Azul (archivo "bel vs avc")
    ("deportiva centenario", "Gigantes del Sur"),   # mismo plantel que Gigantes (Neuquén)
    ("gigantes de neuquen", "Gigantes del Sur"),
    ("belgrano", "Belgrano de Córdoba"),
    ("misiones", "Misiones Vóley"),
    ("ciclista olimpico", "Ciclista Olímpico La Banda"),
    ("ciclistas santiago", "Ciclista Olímpico La Banda"),
    ("olimpico la banda", "Ciclista Olímpico La Banda"),
    ("mendoza voley", "Mendoza Vóley"),
    ("junin de mendoza", "Mendoza Vóley"),         # mismo plantel
    ("parana", "Paraná Vóley"),
    # Brasil
    ("azulim", "Azulim Monte Carmelo"),
    ("guarulhos", "Guarulhos Vôlei"),
    ("jfvolei", "JF Vôlei"),
    ("joinville", "Joinville Vôlei"),
    ("mogi volei", "Mogi Vôlei"),
    ("praia clube", "Praia Clube"),
    ("goias volei", "Goiás Vôlei"),
    ("suzano", "Suzano Vôlei"),
    ("viapol", "São José Vôlei"),
    ("renata", "Vôlei Renata (Campinas)"),
    ("araguari", "Araguari Vôlei"),
    ("swehly", "Swehly Sports Club"),
    ("al rayyan", "Al Rayyan"),
    ("aluron", "Aluron CMC Warta Zawiercie"),
    ("sir susa", "Sir Susa Scai Perugia"),
    ("lagomar", "Lagomar (URU)"),
    ("murano", "Murano (CHI)"),
    ("deportivo jml", "Deportivo JML (ECU)"),
    ("itambe", "Minas Tênis Clube"),          # Itambé = patrocinio de Minas
    ("apan blumenau", "APAN Blumenau"),
    ("apan/eleva", "APAN Blumenau"),
    ("brasilia volei", "Brasília Vôlei"),
    ("rede cuca", "Rede Cuca Vôlei"),
    ("neurologia", "Neurologia Ativa"),
    ("juiz de fora", "JF Vôlei"),
    ("jf volei", "JF Vôlei"),
    ("santo andre", "Santo André"),
    ("atibaia", "Atibaia"),
    ("peerlees", "Peerless"),
    ("perugia", "Sir Susa Scai Perugia"),
    ("shahdab", "Shahdab Yazd"),
    ("foolad sirjan", "Foolad Sirjan"),
    ("argentina sub 19", "Argentina U19"),
    ("seleccion juvenil argentina", "Argentina U21"),
    ("minas tenis", "Minas Tênis Clube"),
    ("cucine lube", "Cucine Lube Civitanova"),
    ("lube civitanova", "Cucine Lube Civitanova"),
    ("funvic", "Funvic Natal"),
    # Extraliga checa (nombres cortos de ciudad que usa la federación)
    ("ceske budejovice", "České Budějovice"), ("pribram", "Příbram"),
    ("usti n", "Ústí nad Labem"), ("benatky n", "Benátky nad Jizerou"),
    ("o. voda", "Odolena Voda"), ("odolena voda", "Odolena Voda"),
    ("karlovarsko", "Karlovarsko"), ("beskydy", "Beskydy"),
    ("lvi praha", "Praha"), ("dukla liberec", "Liberec"), ("vk ostrava", "Ostrava"),
    ("kladno volejbal", "Kladno"), ("volejbal brno", "Brno"), ("fatra zlin", "Zlín"),
    ("c. budejovice", "České Budějovice"), ("fatra zl", "Zlín"),
    # Selecciones nacionales (al final para no pisar nombres de clubes)
    ("chinese taipei", "China Taipéi"),
    ("china", "China"), ("cina", "China"),
    ("colombia", "Colombia"),
    ("czech", "Chequia"), ("czeck", "Chequia"),
    ("japan", "Japón"),
    ("argentina", "Argentina"),
    ("brasil", "Brasil"), ("brazil", "Brasil"),
    ("bulgaria", "Bulgaria"),
    ("canada", "Canadá"),
    ("cuba", "Cuba"),
    ("egypt", "Egipto"),
    ("tunisi", "Túnez"),
    ("france", "Francia"), ("francia", "Francia"),
    ("indonesia", "Indonesia"),
    ("iran", "Irán"),
    ("italy", "Italia"),
    ("kazak", "Kazajistán"),
    ("korea", "Corea del Sur"),
    ("morocco", "Marruecos"),
    ("polonia", "Polonia"), ("poland", "Polonia"),
    ("puerto rico", "Puerto Rico"),
    ("thailand", "Tailandia"),
    ("rkiye", "Turquía"), ("turkey", "Turquía"),
    ("usa u21", "Estados Unidos"), ("u21m usa", "Estados Unidos"),
    ("ukrain", "Ucrania"), ("ukrania", "Ucrania"),
    # Mundial Sub-17 2026 (claves con "u17" donde el nombre podría ser parte de un club)
    ("italia u17", "Italia"), ("india u17", "India"), ("mexico u17", "México"),
    ("romania u17", "Rumania"), ("venezuela u17", "Venezuela"),
    ("espa?a", "España"), ("espana u17", "España"),
    ("argelia", "Argelia"), ("algeria", "Argelia"), ("alg u 17", "Argelia"),
    ("qatar", "Catar"), ("pakistan", "Pakistán"), ("turk?ye", "Turquía"),
]

# Nombres que solo se normalizan si son exactamente así (demasiado genéricos para buscar dentro)
EQUIPOS_EXACTOS = {
    "ciudad": "Ciudad Vóley",
    "moron": "Deportivo Morón",
    "club italiano": "Club Italiano",
    "formosa": "La Unión de Formosa",
    "la union": "La Unión de Formosa",
    "puerto": "Puerto San Martín",
    "neuquen": "Gigantes del Sur",
    "catamarca": "Catamarca Vóley",
    "gigantes": "Gigantes del Sur",
    "union": "La Unión de Formosa",
    "sesi": "SESI",
    "club social y deportivo defens": "Defensores de Banfield",
}

# Archivos que no corresponden al dataset y se excluyen (quedan anotados en errores.csv)
EXCLUIR = {
    "&Universida-U.-De-Santia.dvw": "partido femenino universitario de Chile, no es de la liga masculina",
    "&intento.dvw": "archivo de prueba (Gigantes–Puerto, 4 puntos, julio de 2010)",
}

# Correcciones manuales por archivo, cuando la cabecera del .dvw está mal.
# {nombre_archivo: {"local": ..., "visitante": ...}}
OVERRIDES_EQUIPO = {
    # El rival está cargado como "Club Asociación Mutual Policial" (igual que el local)
    # y su plantel es una copia del de Policial: se borran los nombres del visitante.
    "&2022-10-02 am 02 policial-paraguay.dvw": {"visitante": "Paraguay (rival amistoso)",
                                                "sin_plantel_visitante": True},
    # Partido interno (mismo plantel cargado en ambos lados)
    "&01 am once unidos-once unidos.dvw": {"tipo": "Amistoso (interno)"},
    # Partido de liga (LAC 14-15 nº 082) con "Entrenamiento" cargado como competición
    "&lac1415 082 for-osj 3x0.dvw": {"tipo": "Liga (LVA)"},
    # Cabecera "ACLAV / REGULAR": partido de la fase regular de la liga 2007-08
    "&r00bel_neu.dvw": {"tipo": "Liga (LVA)"},
}


def sin_tildes(s):
    return "".join(c for c in unicodedata.normalize("NFKD", s or "")
                   if not unicodedata.combining(c))


def equipo_std(nombre):
    k = re.sub(r"\s+", " ", sin_tildes(nombre).lower())
    if k.strip() in EQUIPOS_EXACTOS:
        return EQUIPOS_EXACTOS[k.strip()]
    for clave, std in EQUIPOS_STD:
        if clave in k:
            return std
    # sin coincidencia: se quita la temporada pegada al nombre ("Osaka Bluteon 2025-26")
    # y el sufijo de rama masculina de los equipos universitarios de EE. UU.
    nombre = re.sub(r"\s*\(?\bmen'?s\)?(\s+volleyball)?(?=\s*(\(|$))", "", nombre.strip(), flags=re.I).strip()
    nombre = re.sub(r"\s*\((ma|wv)\)\s*$", "", nombre, flags=re.I)
    # U Sports (Canadá): "M-MONTREAL CARABINS 2026", "M-TMU BOLD (2025)" -> "Montreal Carabins", "TMU Bold"
    if re.match(r"^M-[A-Z]", nombre):
        nombre = re.sub(r"\s*\(?20\d\d\)?$", "", nombre[2:]).strip().title()
        for a, b in (("Tmu", "TMU"), ("Unb", "UNB"), ("Rmc", "RMC"), ("Mcmaster", "McMaster"), (" Et Or", " et Or")):
            nombre = nombre.replace(a, b)
        return nombre
    return re.sub(r"\s+(\d{4}[-/]\d{2,4}|\d{2}[-/]\d{2})$", "", nombre.strip())


def nombre_std(apellido, nombre):
    s = f"{apellido or ''} {nombre or ''}"
    s = re.sub(r"\s+", " ", sin_tildes(s).upper()).strip()
    return s


def _hex_unicode(campo: str):
    """DataVolley guarda una copia de los nombres en UTF-16 hex: un dígito de prefijo
    (2 = 1 byte por carácter, 4 = 2 bytes) y luego el texto en hex. None si no aplica."""
    campo = (campo or "").strip().lstrip("\x0f")
    if not campo or campo[0] not in "24" or not re.fullmatch(r"[0-9A-F]+", campo):
        return None
    ancho = 2 if campo[0] == "2" else 4
    h = campo[1:]
    if len(h) % ancho:
        return None
    try:
        return "".join(chr(int(h[i:i + ancho], 16)) for i in range(0, len(h), ancho))
    except ValueError:
        return None


def leer_texto(data: bytes) -> tuple[str, str]:
    try:
        return data.decode("utf-8"), "utf-8"
    except UnicodeDecodeError:
        pass
    # Archivos de PCs de Europa central (p. ej. Chequia) vienen en cp1250. Se elige la
    # codificación cuyos nombres (equipos, entrenadores y jugadores) coinciden más veces
    # con la copia Unicode en hex que guarda DataVolley.
    texto = data.decode("cp1252", errors="replace")
    pares = {"[3TEAMS]": ((1, 6), (3, 7), (4, 8)),
             "[3PLAYERS-H]": ((9, 17), (10, 18)), "[3PLAYERS-V]": ((9, 17), (10, 18))}

    def aciertos(t):
        n, sec = 0, ""
        for l in t.splitlines():
            if l.startswith("["):
                sec = l.strip()
                continue
            if sec == "[3SCOUT]":
                break
            c = l.split(";")
            for i_txt, i_hex in pares.get(sec, ()):
                if len(c) > i_hex:
                    u = _hex_unicode(c[i_hex])
                    n += bool(u) and u.strip() == c[i_txt].strip()
        return n

    alt = data.decode("cp1250", errors="replace")
    if aciertos(alt) > aciertos(texto):
        return alt, "cp1250"
    return texto, "cp1252"


def secciones(lineas):
    out, actual = {}, None
    for l in lineas:
        if l.startswith("[3") and l.rstrip().endswith("]"):
            actual = l.strip()[2:-1]
            out[actual] = []
        elif actual is not None:
            out[actual].append(l)
    return out


def a_int(x):
    try:
        return int(str(x).strip())
    except (ValueError, TypeError):
        return None


def coord(x):
    """Índice de coordenada DV4 -> (índice, x_grilla 1-100, y_grilla 1-101)."""
    v = a_int(x)
    if v is None or v < 0:
        return None, None, None
    return v, (v - 1) % 100 + 1, (v - 1) // 100 + 1


def parse_fecha(s, mes_primero=False):
    formatos = ("%m/%d/%Y", "%d/%m/%Y") if mes_primero else ("%d/%m/%Y", "%m/%d/%Y")
    for fmt in formatos + ("%Y/%m/%d",):
        try:
            return datetime.strptime(s.strip(), fmt).date()
        except (ValueError, AttributeError):
            pass
    return None


def fecha_desde_nombre(nombre):
    m = re.search(r"(20\d\d)-(\d\d)-(\d\d)", nombre)
    if m:
        try:
            return date(int(m[1]), int(m[2]), int(m[3]))
        except ValueError:
            return None
    return None


def tipo_competicion(comp, archivo, liga="Liga (LVA)"):
    t = sin_tildes(f"{comp} {archivo}").lower()
    if liga == "U Sports":  # todos los archivos recibidos son de la liga regular / playoffs universitarios
        return liga
    if "entrenamiento" in t or re.search(r"\bent\d", t):
        return "Entrenamiento"
    if "copa bolivar" in t or "cbolivar" in t:
        return "Copa Bolívar (amistoso)"
    if "copa desafio" in t or "cdesafio" in t:
        return "Copa Desafío"
    if "challenge" in t:
        return "Copa Challenger"
    if "copa social" in t:
        return "Copa Social"
    if "copa rus" in t:
        return "Copa RUS"
    if "mundial de clubes" in t:
        return "Mundial de Clubes"
    if "copa ciudad" in t:
        return "Copa Ciudad 100 años"
    if "supercopa" in t:
        return "Supercopa"
    if "krosno" in t:
        return "Torneo Krosno Karpaty"
    if "copa master" in t or "cmaster" in t:
        return "Copa Máster"
    if "division de honor" in t or "metro20" in t:
        return "División de Honor (Metropolitano)"
    if sin_tildes(comp or "").strip().lower() == "rio":
        return "Torneo en Río (amistoso)"
    if "pre sud" in t or "presud" in t:
        return "Pre Sudamericano"
    if "mineiro" in t or re.search(r"(^|[&\s])cm\d\d ", t):
        return "Torneio Mineiro"
    if (("paulista" in t and ("sub-21" in t or "sub 21" in t or "u21" in t))
            or re.search(r"(^|[&\s])(jsp\d\d|cp21) ", t)):
        return "Campeonato Paulista Sub-21"
    if "catarinense" in t or re.search(r"(^|[&\s])cat\d\d ", t):
        return "Campeonato Catarinense"
    if "paulista" in t or re.search(r"(^|[&\s])sp\d\d ", t):
        return "Campeonato Paulista"
    if "copa do brasil" in t or "copa brasil" in t or re.search(r"(^|[&\s])cb\d\d ", t):
        return "Copa do Brasil"
    if "wchc" in t or "club world championship" in t:
        return "Mundial de Clubes"
    if "copa argentina" in t or "cargentina" in t or re.search(r"\bcarg\d", t):
        return "Copa Argentina"
    if "aclav" in t and "liga" not in t:
        return "Copa ACLAV"
    if "amistoso" in t:
        return "Amistoso"
    if "super 4" in t:
        return "Super 4"
    if ("sul-americano" in t or "sud clubes" in t or "sudamericano" in t
            or "sulamericano" in t or re.search(r"\bsud_", t)):
        return "Sudamericano de Clubes"
    return liga


# Expresión regular del código de acción de scout
RE_SKILL = re.compile(
    r"^(?P<eq>[*a])(?P<num>\d\d|~\d|\d~|~~)(?P<fund>[SRABDEF])(?P<tipo>.)(?P<eval>.)"
    r"(?P<resto>.*)$"
)
RE_VERDE = re.compile(r"^(?P<eq>[*a])\$\$[&A-Z~](?P<tipo>.)?(?P<eval>.)?")
RE_PUNTO = re.compile(r"^(?P<eq>[*a])p(?P<h>\d+):(?P<v>\d+)")
RE_CAMBIO = re.compile(r"^(?P<eq>[*a])c(?P<sale>\d+):(?P<entra>\d+)")


def limpio(c):
    return None if c in (None, "", "~") else c


def parse_resto(fund, resto):
    """Campos opcionales después de la evaluación (posiciones 6+ del código)."""
    r = (resto + "~" * 10)
    combo = limpio(r[0:2].replace("~", "")) if r[0:2] != "~~" else None
    return {
        "combinacion": combo if fund == "A" else None,
        "llamada_armador": combo if fund == "E" else None,
        "objetivo_armado": limpio(r[2]),
        "zona_inicio": a_int(limpio(r[3])),
        "zona_fin": a_int(limpio(r[4])),
        "subzona_fin": limpio(r[5]),
        "subtipo": limpio(r[6]),
        "num_jugadores": a_int(limpio(r[7])),
        "especial": limpio(r[8]),
        "custom": (resto[9:].strip("~") or None) if len(resto) > 9 else None,
    }


def leer_dvw(nombre_archivo, data, temporada=None, liga="Liga (LVA)", mes_primero=False):
    texto, enc = leer_texto(data)
    lineas = texto.splitlines()
    sec = secciones(lineas)
    errores = []

    # --- MATCH ---
    m = (sec.get("MATCH", [""]) + [""])[0].split(";") + [""] * 10
    fecha_hdr = parse_fecha(m[0], mes_primero)
    fecha_fn = fecha_desde_nombre(nombre_archivo)
    fecha, fecha_corr = fecha_hdr, ""
    if fecha_fn and (fecha_hdr is None or abs((fecha_hdr - fecha_fn).days) > 2):
        fecha, fecha_corr = fecha_fn, f"cabecera='{m[0]}' -> fecha del nombre de archivo"

    # --- TEAMS ---
    teams = [t.split(";") + [""] * 6 for t in sec.get("TEAMS", [])[:2]]
    local, visit = teams[0][1].strip(), teams[1][1].strip()
    ov = OVERRIDES_EQUIPO.get(nombre_archivo, {})
    L_STD = ov.get("local", equipo_std(local))
    V_STD = ov.get("visitante", equipo_std(visit))
    # Mundiales juveniles: la categoría va en el nombre ("Argentina U17"), como se usa en el vóley
    m_cat = re.match(r"Mundial Sub-(\d\d)$", liga or "")
    if m_cat:
        L_STD, V_STD = f"{L_STD} U{m_cat[1]}", f"{V_STD} U{m_cat[1]}"

    # Fecha fuera de la temporada del zip (p. ej. fecha en que se scouteó el video)
    def en_temporada(f):
        if temporada[0] == temporada[1]:          # torneo de un año calendario
            return date(temporada[0], 1, 1) <= f <= date(temporada[0], 12, 31)
        return date(temporada[0], 7, 1) <= f <= date(temporada[1], 6, 30)
    if temporada and fecha and not en_temporada(fecha) and fecha.day <= 12:
        invertida = date(fecha.year, fecha.day, fecha.month)
        if en_temporada(invertida):
            fecha_corr = (f"{fecha_corr} | " if fecha_corr else "") + \
                f"fecha {fecha.isoformat()} fuera de temporada -> día/mes invertidos {invertida.isoformat()}"
            fecha = invertida
    # Partido de enero-junio con el año de inicio de temporada (p. ej. 01/02/2007 en 2007/08)
    if temporada and fecha and not en_temporada(fecha) and fecha.year == temporada[0] and fecha.month <= 6:
        corregida = date(temporada[1], fecha.month, fecha.day)
        fecha_corr = (f"{fecha_corr} | " if fecha_corr else "") + \
            f"fecha {fecha.isoformat()} con el año de inicio de temporada -> {corregida.isoformat()}"
        fecha = corregida
    # Fecha ambigua (día y mes <= 12): se guarda la alternativa, por si el dataset mezcla formatos
    fecha_alt = None
    if fecha and fecha_hdr and fecha == fecha_hdr and fecha.day <= 12 and fecha.day != fecha.month:
        alt = date(fecha.year, fecha.day, fecha.month)
        if not temporada or en_temporada(alt):
            fecha_alt = alt
    if temporada and fecha and not en_temporada(fecha):
        fecha_corr = (f"{fecha_corr} | " if fecha_corr else "") + \
            f"fecha {fecha.isoformat()} fuera de la temporada {temporada[0]}/{temporada[1]} -> vacía"
        fecha = None

    more = (sec.get("MORE", [""]) + [""])[0].split(";") + [""] * 8
    scouter = more[5].strip()
    if "@" in scouter:  # no publicar e-mails de terceros
        scouter = scouter.split("@")[0]

    gen = {}
    for l in sec.get("DATAVOLLEYSCOUT", []):
        if ":" in l:
            k, v = l.split(":", 1)
            gen[k.strip()] = v.strip()

    # --- SETS ---
    sets = []
    for i, l in enumerate(sec.get("SET", []), start=1):
        p = l.split(";") + [""] * 7
        fin = p[4].replace(" ", "")
        if not fin or "-" not in fin:
            continue
        h, v = (a_int(x) for x in fin.split("-", 1))
        if h is None or v is None:
            continue
        sets.append({"set": i, "puntos_local": h, "puntos_visitante": v,
                     "parcial_8": p[1].replace(" ", ""),
                     "parcial_16": p[2].replace(" ", ""),
                     "parcial_21": p[3].replace(" ", ""),
                     "duracion_min": a_int(p[5])})
    def set_terminado(s):
        objetivo = 15 if s["set"] == 5 else 25
        return (max(s["puntos_local"], s["puntos_visitante"]) >= objetivo
                and abs(s["puntos_local"] - s["puntos_visitante"]) >= 2)
    for s in sets:
        s["set_completo"] = set_terminado(s)
    sets_l = sum(s["set_completo"] and s["puntos_local"] > s["puntos_visitante"] for s in sets)
    sets_v = sum(s["set_completo"] and s["puntos_visitante"] > s["puntos_local"] for s in sets)

    # --- PLAYERS ---
    jugadores = []
    lookup = {}
    for lado, key in (("local", "PLAYERS-H"), ("visitante", "PLAYERS-V")):
        for l in sec.get(key, []):
            p = l.split(";") + [""] * 16
            num = a_int(p[1])
            if num is None:
                continue
            if lado == "visitante" and ov.get("sin_plantel_visitante"):
                p[9] = p[10] = p[13] = ""
            j = {
                "equipo": lado,
                "equipo_nombre": (L_STD if lado == "local" else V_STD),
                "numero": num,
                "jugador_id_dv": p[8].strip(),
                "apellido": p[9].strip(),
                "nombre": p[10].strip(),
                "jugador_std": (None if re.match(r"^(UNKNOWN PLAYER|JUGADOR\b|\d+ PLAYER$|SHIRT BLOOD$|BLOOD SHIRT$)", nombre_std(p[9], p[10]))
                                else nombre_std(p[9], p[10]) or None),
                "rol_cod": p[13].strip() or None,
                "rol": ROLES.get(p[13].strip()),
                "es_libero": p[12].strip().upper() == "L" or p[13].strip() == "1",
                **{f"pos_inicial_set{k}": (p[2 + k].strip() or None) for k in range(1, 6)},
            }
            jugadores.append(j)
            lookup[(lado, num)] = j

    # --- SCOUT ---
    acciones = []
    marcador = {"h": 0, "v": 0}
    set_actual = 1
    rally = 0
    rally_buffer = []
    saque_rally = None

    def cerrar_rally(ganador, h, v):
        for a in rally_buffer:
            a["punto_ganado_por"] = ganador
            a["gana_rally_equipo_accion"] = (a["equipo"] == ganador)
            a["marcador_local_despues"] = h
            a["marcador_visitante_despues"] = v

    for nlinea, l in enumerate(sec.get("SCOUT", []), start=1):
        if not l.strip():
            continue
        f = l.split(";") + [""] * 27
        code = f[0].strip()
        st = a_int(f[8])
        if st:
            set_actual = st

        if RE_PUNTO.match(code):
            mm = RE_PUNTO.match(code)
            ganador = "local" if mm["eq"] == "*" else "visitante"
            h, v = int(mm["h"]), int(mm["v"])
            cerrar_rally(ganador, h, v)
            marcador = {"h": h, "v": v}
            rally_buffer, saque_rally = [], None
            continue
        if code.startswith("**") and code.lower().endswith("set"):
            marcador = {"h": 0, "v": 0}
            rally_buffer, saque_rally = [], None
            continue
        if (re.match(r"^[*a](P\d+|z\d|T|STOP|[cC]:?\d+[:.\-]\d+)", code) or ">LUp" in code
                or code.startswith(">")):
            continue  # armador en cancha, zona del armador, tiempo, cambio, alineación, comentario

        ms = RE_SKILL.match(code)
        mv = RE_VERDE.match(code)
        if not ms and not mv:
            errores.append({"archivo": nombre_archivo, "linea_scout": nlinea,
                            "contenido": l, "motivo": "código no reconocido"})
            continue

        eq = (ms or mv)["eq"]
        lado = "local" if eq == "*" else "visitante"
        if ms:
            fund, tipo, ev = ms["fund"], ms["tipo"], ms["eval"]
            num = a_int(ms["num"].replace("~", "")) if "~" not in ms["num"] else None
            extra = parse_resto(fund, ms["resto"])
        else:
            fund, tipo, ev, num = "&", mv["tipo"], mv["eval"], None
            extra = parse_resto("&", "")

        if not rally_buffer:          # primera acción después de un punto
            rally += 1
        if fund == "S":
            saque_rally = lado
        tipos = TIPO_SAQUE if fund in "SR" else TIPO_TEMPO
        j = lookup.get((lado, num), {}) if num is not None else {}
        ci = coord(f[4]); cm = coord(f[5]); cf = coord(f[6])

        a = {
            "set": set_actual,
            "rally_n": rally,
            "marcador_local": marcador["h"],
            "marcador_visitante": marcador["v"],
            "equipo": lado,
            "equipo_nombre": (L_STD if lado == "local" else V_STD),
            "rival_nombre": (V_STD if lado == "local" else L_STD),
            "jugador_numero": num,
            "jugador_nombre": j.get("jugador_std"),
            "jugador_rol": j.get("rol"),
            "fundamento_cod": fund,
            "fundamento": FUNDAMENTOS.get(fund),
            "tipo_cod": limpio(tipo),
            "tipo": tipos.get(tipo) if fund != "&" else None,
            "evaluacion_cod": limpio(ev),
            "evaluacion": EVALUACION.get(fund, {}).get(ev),
            **extra,
            "subtipo_desc": SUBTIPO_ATAQUE.get(extra["subtipo"]) if fund == "A" else None,
            "equipo_saque": saque_rally,
            "fase_juego": (None if saque_rally is None else
                           ("Break point" if saque_rally == lado else "Side-out")),
            "fase_ataque_raw": limpio(f[2].strip()),
            "fase_punto_raw": limpio(f[1].strip()),
            "rotacion_local": a_int(f[9]),
            "rotacion_visitante": a_int(f[10]),
            "coord_inicio": ci[0], "inicio_x": ci[1], "inicio_y": ci[2],
            "coord_medio": cm[0], "medio_x": cm[1], "medio_y": cm[2],
            "coord_fin": cf[0], "fin_x": cf[1], "fin_y": cf[2],
            "hora": f[7].strip() or None,
            "video_seg": a_int(f[12]),
            **{f"local_p{k}": a_int(f[13 + k]) for k in range(1, 7)},
            **{f"visit_p{k}": a_int(f[19 + k]) for k in range(1, 7)},
            "codigo": code,
            "linea_scout": nlinea,
            "punto_ganado_por": None,
            "gana_rally_equipo_accion": None,
            "marcador_local_despues": None,
            "marcador_visitante_despues": None,
        }
        acciones.append(a)
        rally_buffer.append(a)

    # Validación: último marcador de cada set en el scout vs sección [3SET]
    fin_scout = {}
    for a in acciones:
        if a["marcador_local_despues"] is not None:
            fin_scout[a["set"]] = (a["marcador_local_despues"], a["marcador_visitante_despues"])
    discrepancias = []
    for s in sets:
        fs = fin_scout.get(s["set"])
        if fs != (s["puntos_local"], s["puntos_visitante"]):
            discrepancias.append(f"set{s['set']}: cabecera {s['puntos_local']}-{s['puntos_visitante']}"
                                 f" / scout {fs[0]}-{fs[1]}" if fs else f"set{s['set']}: sin puntos en scout")

    partido = {
        "archivo": nombre_archivo,
        "fecha": fecha.isoformat() if fecha else None,
        "fecha_corregida": fecha_corr or None,
        "_fecha_alt": fecha_alt,
        "hora": m[1].strip() or None,
        "temporada_original": m[2].strip() or None,
        "competicion_original": m[3].strip() or None,
        "fase_original": m[4].strip() or None,
        "tipo_competicion": ov.get("tipo", tipo_competicion(m[3], nombre_archivo, liga)),
        "equipo_local_original": local,
        "equipo_visitante_original": visit,
        "equipo_local": L_STD,
        "equipo_visitante": V_STD,
        "sets_local": sets_l,
        "sets_visitante": sets_v,
        "resultado_sets": ";".join(f"{s['puntos_local']}-{s['puntos_visitante']}" for s in sets),
        "partido_completo": max(sets_l, sets_v) >= 3 or (tipo_competicion(m[3], nombre_archivo, liga) == "Amistoso" and len(sets) >= 4),
        "ganador": (L_STD if sets_l >= 3 else V_STD if sets_v >= 3 else None),
        "scouter": scouter or None,
        "software": f"{gen.get('GENERATOR-PRG', '')} {gen.get('GENERATOR-REL', '')}".strip() or None,
        "encoding_original": enc,
        "n_acciones": len(acciones),
        "n_lineas_no_reconocidas": len(errores),
        "validacion_marcador": "OK" if not discrepancias else " | ".join(discrepancias),
    }
    return partido, sets, jugadores, acciones, errores


def match_id(nombre):
    return "m" + hashlib.md5(nombre.encode("utf-8")).hexdigest()[:8]


# Extensiones que se leen. ".leg" es un .dvw normal con otra extensión (aparece en 2009-10).
# No se incluye ".vis": en 2014-15 era una copia con el scout duplicado.
EXTENSIONES = (".dvw", ".leg")


def iterar_dvw(entrada: Path):
    if entrada.is_file() and entrada.suffix.lower() == ".zip":
        with zipfile.ZipFile(entrada) as z:
            for n in sorted(z.namelist()):
                if n.lower().endswith(EXTENSIONES) and not n.startswith("__MACOSX"):
                    yield Path(n).name, z.read(n)
    else:
        for p in sorted(x for x in entrada.rglob("*") if x.is_file()
                        and x.suffix.lower() in EXTENSIONES):
            yield p.name, p.read_bytes()


def resolver_fechas_ambiguas(partidos, tolerancia=3):
    """Dataset con cabeceras en dd/mm y en mm/dd mezcladas: para cada fecha ambigua (p. ej.
    05/04) se elige la lectura que encaja entre el partido anterior y el siguiente por número
    de archivo (los números siguen el orden del calendario). Se recorre en orden de número y
    cada fecha resuelta sirve de referencia para la siguiente."""
    num = pd.to_numeric(partidos["archivo"].str.extract(r"^&?\s*(\d+)")[0], errors="coerce")
    fechas = pd.to_datetime(partidos["fecha"])
    seguras = partidos["_fecha_alt"].isna() & num.notna() & fechas.notna()
    if seguras.sum() < 4:
        return partidos
    ref = dict(zip(num[seguras], fechas[seguras]))
    tol = pd.Timedelta(days=tolerancia)

    def desajuste(n, f):
        antes = [ref[k] for k in ref if k < n]
        despues = [ref[k] for k in ref if k > n]
        d = pd.Timedelta(0)
        if antes:
            lo = sorted(antes)[-1] if len(antes) < 3 else pd.Series(sorted(k for k in ref if k < n)[-3:]).map(ref).median()
            d += max(pd.Timedelta(0), lo - f - tol)
        if despues:
            hi = pd.Series(sorted(k for k in ref if k > n)[:3]).map(ref).median()
            d += max(pd.Timedelta(0), f - hi - tol)
        return d

    n_cambios = 0
    ambiguas = partidos.index[partidos["_fecha_alt"].notna() & num.notna()]
    for i in sorted(ambiguas, key=lambda k: num[k]):
        n, f = num[i], fechas[i]
        alt = pd.Timestamp(partidos.at[i, "_fecha_alt"])
        if desajuste(n, alt) < desajuste(n, f):
            nota = (f"fecha {partidos.at[i, 'fecha']} ambigua -> día/mes invertidos {alt.date()} "
                    f"(encaja con los partidos de número anterior y posterior)")
            prev = partidos.at[i, "fecha_corregida"]
            partidos.at[i, "fecha_corregida"] = f"{prev} | {nota}" if isinstance(prev, str) else nota
            partidos.at[i, "fecha"] = alt.date().isoformat()
            f = alt
            n_cambios += 1
        ref[n] = f
    print(f"Fechas dd/mm y mm/dd mezcladas: {n_cambios} fechas ambiguas invertidas según los partidos vecinos")
    return partidos


def marcar_duplicados(partidos: pd.DataFrame) -> pd.DataFrame:
    """Mismo partido scouteado en dos archivos: mismos equipos, fecha ±1 día
    y mismos marcadores por set (aunque local/visitante estén invertidos).
    Se elige como principal el archivo con más acciones."""
    def firma(r):
        sets = r["resultado_sets"].split(";") if r["resultado_sets"] else []
        a, b = r["equipo_local"], r["equipo_visitante"]
        if a > b:
            a, b = b, a
            sets = ["-".join(s.split("-")[::-1]) for s in sets]
        return f"{a}|{b}|{';'.join(sets)}"

    partidos = partidos.copy()
    partidos["_firma"] = partidos.apply(firma, axis=1)
    partidos["_f"] = pd.to_datetime(partidos["fecha"])
    partidos["grupo_duplicado"] = None
    partidos["es_principal"] = True
    g = 0
    for firma_, grp in partidos.groupby("_firma"):
        if len(grp) < 2:
            continue
        grp = grp.sort_values("_f")
        # agrupa por cercanía de fecha
        bloques, actual = [], [grp.index[0]]
        for i_prev, i in zip(grp.index[:-1], grp.index[1:]):
            if (partidos.at[i, "_f"] - partidos.at[i_prev, "_f"]).days <= 1:
                actual.append(i)
            else:
                bloques.append(actual); actual = [i]
        bloques.append(actual)
        for b in bloques:
            if len(b) < 2:
                continue
            g += 1
            principal = partidos.loc[b, "n_acciones"].idxmax()
            fmin = partidos.loc[b, "_f"].min()
            for i in b:
                if partidos.at[i, "_f"] != fmin:
                    nota = f"fecha cabecera {partidos.at[i, 'fecha']} -> {fmin.date()} (igualada al otro archivo del mismo partido)"
                    prev = partidos.at[i, "fecha_corregida"]
                    partidos.at[i, "fecha_corregida"] = f"{prev} | {nota}" if isinstance(prev, str) else nota
                    partidos.at[i, "fecha"] = fmin.date().isoformat()
                partidos.at[i, "grupo_duplicado"] = f"dup{g:02d}"
                partidos.at[i, "es_principal"] = (i == principal)
    return partidos.drop(columns=["_firma", "_f"])


# ---------------------------------------------------------------------------
# Unificación de jugadores entre archivos/scouters
# ---------------------------------------------------------------------------
from difflib import SequenceMatcher


def _tokens(s):
    s = re.sub(r"[^A-Z ]", " ", sin_tildes(s or "").upper())
    return [t for t in s.split() if len(t) > 1]


def _parecidos(t1, t2):
    return t1 == t2 or (min(len(t1), len(t2)) >= 4
                        and SequenceMatcher(None, t1, t2).ratio() >= 0.8)


def _comparar(a, b):
    chico, grande = (a, b) if len(a["toks"]) <= len(b["toks"]) else (b, a)
    usados, n = set(), 0
    for t in chico["toks"]:
        for i, u in enumerate(grande["toks"]):
            if i not in usados and _parecidos(t, u):
                usados.add(i); n += 1
                break
    cov = n / len(chico["toks"]) if chico["toks"] else 0
    ape = any(_parecidos(x, y) for x in a["ape"] for y in b["ape"])
    return n, cov, ape


def unificar_jugadores(jug: pd.DataFrame):
    """Asigna jugador_uid / jugador_canonico agrupando variantes del mismo jugador.

    Reglas (dentro del mismo equipo normalizado):
      1. Mismo número de camiseta y todas las palabras del nombre más corto están
         en el otro (admite errores de tipeo), con apellido coincidente o >=2 palabras.
      2. Distinto número: coincide el apellido y todas las palabras del nombre
         más corto (>=2) -> se une pero queda marcado para revisar.
      3. Entre equipos distintos solo se une si el nombre es idéntico (>=2 palabras).
    Nunca se unen dos registros que aparecen en el mismo partido.
    """
    sin_nombre = jug[jug["jugador_std"].isna()].copy()
    jug = jug[jug["jugador_std"].notna()].copy()
    jug["_key"] = list(zip(jug["equipo_nombre"], jug["numero"], jug["jugador_std"]))
    nodos = {}
    for k, g in jug.groupby("_key", sort=False):
        nodos[k] = {"key": k, "equipo": k[0], "numero": k[1],
                    "toks": _tokens(k[2]), "ape": _tokens(g["apellido"].iloc[0]),
                    "partidos": set(g["match_id"]), "n": g["match_id"].nunique()}
    padre = {k: k for k in nodos}
    partidos_cl = {k: set(v["partidos"]) for k, v in nodos.items()}
    motivo = {k: set() for k in nodos}

    def raiz(k):
        while padre[k] != k:
            padre[k] = padre[padre[k]]
            k = padre[k]
        return k

    def unir(a, b, razon):
        ra, rb = raiz(a), raiz(b)
        if ra == rb or partidos_cl[ra] & partidos_cl[rb]:
            return
        padre[rb] = ra
        partidos_cl[ra] |= partidos_cl.pop(rb)
        motivo[ra] |= motivo.pop(rb) | {razon}

    lista = sorted(nodos.values(), key=lambda x: -x["n"])
    por_equipo = {}
    for nd in lista:
        por_equipo.setdefault(nd["equipo"], []).append(nd)
    for paso in (1, 2):
        for eq, nds in por_equipo.items():
            for i, a in enumerate(nds):
                for b in nds[i + 1:]:
                    n, cov, ape = _comparar(a, b)
                    if paso == 1 and a["numero"] == b["numero"] and cov == 1 and (ape or n >= 2):
                        unir(a["key"], b["key"],
                             "exacta" if a["toks"] == b["toks"] else "variante de nombre, mismo número")
                    elif paso == 2 and a["numero"] != b["numero"] and ape and n >= 2 and cov == 1:
                        unir(a["key"], b["key"], "distinto número")
    for i, a in enumerate(lista):
        for b in lista[i + 1:]:
            if a["equipo"] != b["equipo"] and len(a["toks"]) >= 2 and sorted(a["toks"]) == sorted(b["toks"]):
                unir(a["key"], b["key"], "cambio de equipo")

    grupos = {}
    for k in nodos:
        grupos.setdefault(raiz(k), []).append(nodos[k])
    filas, mapa, usados = [], {}, {}
    for r, nds in grupos.items():
        canon = max(nds, key=lambda x: (len(x["toks"]) >= 2, x["n"], len(x["toks"])))
        nombre = canon["key"][2]
        slug = re.sub(r"[^A-Z0-9]+", "_", nombre).strip("_") or "SIN_NOMBRE"
        if slug in usados:
            slug = f"{slug}__{re.sub(r'[^A-Z0-9]+', '_', sin_tildes(canon['equipo']).upper())}"
        while slug in usados:
            slug += "_2"
        usados[slug] = True
        razones = motivo.get(r, set()) - {"exacta"}
        filas.append({
            "jugador_uid": slug,
            "jugador_canonico": nombre,
            "equipos": " | ".join(sorted({n["equipo"] for n in nds})),
            "numeros": " | ".join(str(x) for x in sorted({n["numero"] for n in nds})),
            "variantes": " | ".join(sorted({n["key"][2] for n in nds})),
            "n_partidos": len(partidos_cl[r]),
            "union": "; ".join(sorted(razones)) or ("exacta" if len(nds) > 1 else "única"),
            "revisar": bool(razones & {"distinto número", "cambio de equipo"}),
        })
        for n in nds:
            mapa[n["key"]] = (slug, nombre)
    jug["jugador_uid"] = jug["_key"].map(lambda k: mapa[k][0])
    jug["jugador_canonico"] = jug["_key"].map(lambda k: mapa[k][1])
    resumen = pd.DataFrame(filas).sort_values(["equipos", "jugador_canonico"])
    jug = pd.concat([jug.drop(columns="_key"), sin_nombre]).sort_index()
    return jug, resumen


def propagar_roles(jug: pd.DataFrame, resumen: pd.DataFrame):
    """Completa el rol de un jugador en los partidos donde el scouter no lo cargó, usando el rol
    que tiene ese mismo jugador (jugador_uid) en otros archivos de la temporada.

    - rol_origen = "archivo" si el rol venía en el .dvw, "propagado" si se tomó de otro partido.
    - Si un jugador tiene roles distintos en distintos archivos, se usa el más frecuente sin
      contar los de líbero (que DataVolley marca por partido), y se anota en jugadores_unificados.
    """
    jug = jug.copy()
    jug["rol_origen"] = jug["rol"].notna().map({True: "archivo", False: None})
    con_rol = jug[jug["rol"].notna() & jug["jugador_uid"].notna()]

    def elegir(s):
        sin_libero = s[s != "Líbero"]
        base = sin_libero if len(sin_libero) else s
        return base.mode().iloc[0]

    rol_uid = con_rol.groupby("jugador_uid")["rol"].agg(elegir)
    roles_distintos = con_rol.groupby("jugador_uid")["rol"].agg(lambda s: " | ".join(sorted(set(s))))
    faltan = jug["rol"].isna() & jug["jugador_uid"].isin(rol_uid.index)
    jug.loc[faltan, "rol"] = jug.loc[faltan, "jugador_uid"].map(rol_uid)
    jug.loc[faltan, "rol_origen"] = "propagado"
    codigos = {v: k for k, v in ROLES.items()}
    jug.loc[faltan, "rol_cod"] = jug.loc[faltan, "rol"].map(codigos)
    resumen = resumen.copy()
    resumen["rol"] = resumen["jugador_uid"].map(rol_uid)
    resumen["roles_en_archivos"] = resumen["jugador_uid"].map(roles_distintos)
    return jug, resumen


def main(entrada, salida):
    entrada, salida = Path(entrada), Path(salida)
    salida.mkdir(parents=True, exist_ok=True)
    P, S, J, A, E = [], [], [], [], []
    m = re.search(r"(20\d\d)-(20\d\d)", f"{entrada.name} {salida.name}")
    if m:
        temporada = (int(m[1]), int(m[2]))
    else:
        # un solo año: NCAA 2026 = julio 2025 a junio 2026; un torneo (p. ej. Mundial 2025) = año calendario
        m1 = re.search(r"(?<!\d)(20\d\d)(?!\d)", f"{entrada.name} {salida.name}")
        if m1 and "ncaa" in f"{entrada.name} {salida.name}".lower():
            temporada = (int(m1[1]) - 1, int(m1[1]))
        elif m1:
            temporada = (int(m1[1]), int(m1[1]))
        else:
            temporada = None
    # Nombre de la liga principal según el nombre del zip/carpeta
    nombres = f"{entrada.name} {salida.name}".lower()
    liga = ("Superliga" if "superliga" in nombres else "NCAA" if "ncaa" in nombres
            else f"Mundial Sub-{_m_cat[1]}" if (_m_cat := re.search(r"mundial.*(?:sub.?|u)(\d\d)", nombres))
            else "U Sports" if re.search(r"u.?sports|canad", nombres)
            else "Extraliga" if "extraliga" in nombres else "Liga (LVA)")
    archivos = list(iterar_dvw(entrada))
    # Formato de fecha del dataset: si ninguna cabecera tiene el primer número > 12 y alguna
    # tiene el segundo > 12, todas están en mm/dd/aaaa (formato de EE. UU.), también las
    # ambiguas como 12/07/2023 (7 de diciembre, no 12 de julio).
    primeros, segundos = 0, 0
    for _, data in archivos:
        mm = re.search(rb"\[3MATCH\]\r?\n(\d{1,2})/(\d{1,2})/\d{4}", data)
        if mm:
            primeros += int(mm[1]) > 12
            segundos += int(mm[2]) > 12
    mes_primero = primeros == 0 and segundos > 0
    if mes_primero:
        print(f"Fechas en formato mm/dd/aaaa ({segundos} cabeceras con día > 12 en segundo lugar)")
    for nombre, data in archivos:
        mid = match_id(nombre)
        if nombre in EXCLUIR:
            E.append({"match_id": None, "archivo": nombre, "linea_scout": None,
                      "contenido": "", "motivo": f"excluido: {EXCLUIR[nombre]}"})
            print(f"AVISO: {nombre} excluido ({EXCLUIR[nombre]})")
            continue
        if not data.strip(b"\x00 \r\n\t") or b"[3SCOUT]" not in data:
            E.append({"match_id": None, "archivo": nombre, "linea_scout": None,
                      "contenido": f"{len(data)} bytes",
                      "motivo": "archivo vacío, corrupto o en formato antiguo (sin [3SCOUT]); excluido"})
            print(f"AVISO: {nombre} está vacío o corrupto y se excluyó")
            continue
        p, s, j, a, e = leer_dvw(nombre, data, temporada, liga, mes_primero)
        if not a:
            E.append({"match_id": None, "archivo": nombre, "linea_scout": None, "contenido": "",
                      "motivo": "archivo sin acciones de scout (solo cabecera/planteles); excluido"})
            print(f"AVISO: {nombre} no tiene acciones y se excluyó")
            continue
        P.append({"match_id": mid, **p})
        S += [{"match_id": mid, **x} for x in s]
        J += [{"match_id": mid, **x} for x in j]
        A += [{"match_id": mid, **x} for x in a]
        E += [{"match_id": mid, **x} for x in e]

    partidos = pd.DataFrame(P)
    if primeros and segundos:
        partidos = resolver_fechas_ambiguas(partidos)
    partidos = marcar_duplicados(partidos.drop(columns="_fecha_alt")).sort_values(["fecha", "archivo"])
    jugadores, resumen_jug = unificar_jugadores(pd.DataFrame(J))
    jugadores, resumen_jug = propagar_roles(jugadores, resumen_jug)
    acciones = pd.DataFrame(A)
    # rol actualizado en acciones (incluye los roles propagados)
    rol_map = (jugadores.drop_duplicates(["match_id", "equipo", "numero"])
               .set_index(["match_id", "equipo", "numero"])["rol"])
    acciones["jugador_rol"] = pd.Series(
        list(zip(acciones["match_id"], acciones["equipo"], acciones["jugador_numero"])),
        index=acciones.index).map(rol_map.to_dict())
    uid = (jugadores.drop_duplicates(["match_id", "equipo", "numero"])
           .set_index(["match_id", "equipo", "numero"])[["jugador_uid", "jugador_canonico"]])
    acciones = acciones.join(uid, on=["match_id", "equipo", "jugador_numero"])
    pos = acciones.columns.get_loc("jugador_nombre") + 1
    for c in ["jugador_canonico", "jugador_uid"]:
        acciones.insert(pos, c, acciones.pop(c))
    info = partidos.set_index("match_id")[["fecha", "tipo_competicion", "es_principal"]]
    acciones = acciones.join(info, on="match_id")
    acciones.insert(1, "accion_id", range(1, len(acciones) + 1))
    cols = ["match_id", "accion_id", "fecha", "tipo_competicion", "es_principal"]
    acciones = acciones[cols + [c for c in acciones.columns if c not in cols]]

    for col in ["jugador_numero", "zona_inicio", "zona_fin", "num_jugadores",
                "rotacion_local", "rotacion_visitante", "coord_inicio", "coord_medio",
                "coord_fin", "inicio_x", "inicio_y", "medio_x", "medio_y", "fin_x",
                "fin_y", "video_seg", "marcador_local_despues",
                "marcador_visitante_despues"] + [f"local_p{k}" for k in range(1, 7)] \
            + [f"visit_p{k}" for k in range(1, 7)]:
        acciones[col] = acciones[col].astype("Int64")

    kw = dict(index=False, encoding="utf-8")
    # comprimido: GitHub rechaza archivos >100 MB y avisa desde 50 MB.
    # pandas lo lee directo: pd.read_csv("acciones.csv.gz")
    acciones.to_csv(salida / "acciones.csv.gz", compression={"method": "gzip", "mtime": 0}, **kw)
    partidos.to_csv(salida / "partidos.csv", **kw)
    pd.DataFrame(S).to_csv(salida / "sets.csv", **kw)
    jugadores.to_csv(salida / "jugadores.csv", **kw)
    resumen_jug.to_csv(salida / "jugadores_unificados.csv", **kw)
    pd.DataFrame(E, columns=["match_id", "archivo", "linea_scout", "contenido", "motivo"]) \
        .to_csv(salida / "errores.csv", **kw)
    print(f"{len(partidos)} partidos, {len(acciones)} acciones, {len(E)} líneas no reconocidas")


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print(__doc__)
        sys.exit(1)
    main(sys.argv[1], sys.argv[2])
