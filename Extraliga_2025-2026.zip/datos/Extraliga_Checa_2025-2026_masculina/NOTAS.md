# Extraliga checa masculina 2025-26 (ČEZ Extraliga mužů): notas del dataset

Resumen y problemas específicos de esta temporada. La estructura de las tablas, el diccionario de
columnas y el origen de los datos están en el [README principal](../../README.md).

## Resumen

| | 2025-26 |
|---|---|
| Archivos / partidos distintos | 185 / 185 (sin duplicados) |
| Acciones | 180.094 |
| Competición | `tipo_competicion = "Extraliga"` en todos los partidos (fase regular y playoffs) |
| Fechas | 23/10/2025 → 05/05/2026 |
| Fase regular | **Completa**: 156 partidos, 13 equipos, ida y vuelta |
| Playoffs | 29 partidos: 4 de la ronda previa, 13 de cuartos, 7 de semis y los 5 de la final, que ganó **Karlovarsko 3-2 a Praha**. Faltan 2: el tercero de Příbram–Ostrava (ronda previa) y el cuarto de Praha–Brno (cuartos) |
| Equipos | Los mismos 13 de las dos temporadas anteriores |
| Scouters | Ondra Smolka (43 archivos), Zdenek Sklenar (35), Agustín Briscioli (33, analista de Praha), Adam Šimonek (30) y otros 10; 12 archivos sin nombre |
| Acciones con coordenadas | < 1 % (sí hay zonas en el 58 % de las acciones) |
| Rol de los jugadores | 98,8 % de los registros |
| Jugadores (nombres distintos → unificados) | 239 → 229 |

Es scout real de la federación checa. Indicadores generales: side-out 59,1 %, eficiencia de ataque
0,296, 5,84 acciones por rally y 0,44 códigos verdes por rally. En 184 de los 185 partidos, el
marcador de cada set reconstruido desde el scout coincide con la cabecera.

## Advertencias importantes

- **Local y visitante invertidos en 21 partidos**: 18 de Praha (otra vez el analista de Praha pone a
  su equipo siempre como "*"), 2 de Kladno y 1 de Karlovarsko. El local real está en el código del
  nombre del archivo (`..._BEN-PRA.dvw` = Benátky local). Para análisis de localía:

  ```python
  cod_equipo = {"KAR": "Karlovarsko", "PRA": "Praha", "LIB": "Liberec", "VOD": "Odolena Voda",
                "ODO": "Odolena Voda", "BUD": "České Budějovice", "BRN": "Brno", "KLA": "Kladno",
                "PRI": "Příbram", "PR": "Příbram", "BEN": "Benátky nad Jizerou", "ZLI": "Zlín",
                "OST": "Ostrava", "OTS": "Ostrava", "BES": "Beskydy", "UST": "Ústí nad Labem"}
  cod = p["archivo"].str.extract(r"_([A-Z]{2,3})-([A-Z]{2,3})(?:_|\.)")
  invertido = (cod[0].map(cod_equipo) == p["equipo_visitante"]) & (cod[1].map(cod_equipo) == p["equipo_local"])
  p["local_real"] = p["equipo_local"].where(~invertido, p["equipo_visitante"])
  p["visitante_real"] = p["equipo_visitante"].where(~invertido, p["equipo_local"])
  ```

  Aun así queda una duda: Kladno–Beskydy aparece dos veces como local Kladno (30/10 y 15/01) y falta
  Beskydy–Kladno. Uno de los dos archivos está invertido, pero el nombre no permite saber cuál.
- **Playoffs.** `fase_original` dice "2. část" en los playoffs, salvo en el quinto partido de la
  final (`FINAL_05`), que dice "1. část" por error. Usen el nombre del archivo:

  ```python
  p["playoff"] = p["archivo"].str.contains("PLAYOFF|SEMI|FINAL")
  ```

- **Fechas en formato estadounidense** (mes/día/año) en todas las cabeceras; el conversor lo detecta
  para el dataset completo.
- **Nombres de equipo.** Venían como "Č. Budějovice", "C. Budejovice", "Fatra ZlĂ­n" (un archivo con
  texto UTF-8 mal codificado desde el origen)…; se normalizaron igual que en las temporadas
  anteriores.
- **Un archivo con el nombre equivocado**: `&11153_..._BRN-PRI` es Brno–Odolena Voda según la
  cabecera.
- **Scouters con nombres rotos o en varias formas** ("Agustin Briscioli", "Agutin Briscioli", "Briscioli
  Agustin Ignacio"…). Límpienlo antes de agrupar por `scouter`.
- **Un set con un punto de diferencia** entre la cabecera y el scout (Karlovarsko–Zlín, 11170, set 4).
- **3 líneas descartadas** (`errores.csv`) con códigos que no son de DataVolley.
- Sin coordenadas: para el análisis espacial, usen `zona_inicio`/`zona_fin`.

## Jugadores para revisar

En `jugadores_unificados.csv` hay 31 filas con `revisar = True`, casi todas de jugadores con dos o
tres números en el mismo equipo. Příbram concentra varios casos con los números 2, 4 y 8 cruzados
entre jugadores, seguramente un plantel mal cargado en algún archivo. En Liberec hay dos
"Vesely Jakub" con números distintos (1/12/15 y 2/6). Quedaron como dos `jugador_uid` porque
coinciden en partidos; puede ser un error de plantel o dos jugadores con el mismo nombre.
