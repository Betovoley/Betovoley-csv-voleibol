# PlusLiga polaca masculina 2024-25: notas del dataset

Resumen y problemas específicos de esta temporada. La estructura de las tablas, el diccionario de
columnas y el origen de los datos están en el [README principal](../../README.md).

> **Temporada vista desde algunos clubes.** Los 91 archivos son de VolleyMetrics y se concentran en
> Bogdanka LUK Lublin (29 partidos), Indykpol AZS Olsztyn (26), Barkom-Kazhany Lviv (23) y GKS
> Katowice (21). No es la liga completa (la liga regular tuvo 240 partidos).

## Resumen

| | 2024-25 |
|---|---|
| Archivos / partidos distintos | 91 / 91 (sin duplicados) |
| Acciones | 90.959 |
| Competiciones (`tipo_competicion`) | **PlusLiga** 87, **Pretemporada** 3 (antes del 13/09/2024, cuando empezó la liga) y **Amistoso** 1 (Perugia–Lublin) |
| Fechas | 31/08/2024 → 10/05/2025 |
| Playoffs | 2 partidos de la semifinal Lublin–Jastrzębski y **la final completa** (4 partidos), que ganó **Bogdanka LUK Lublin 3-1 a Aluron CMC Warta Zawiercie**, su primer título |
| Equipos | Los 16 de la liga, más Perugia en el amistoso |
| Scouter | VolleyMetrics en todos los archivos |
| Acciones con coordenadas | **92 %**: muy bueno para análisis espacial |
| Rol de los jugadores | 8 % de los registros (VolleyMetrics casi no carga roles) |
| Jugadores (nombres distintos → unificados) | 477 → 469 |

Es scout real. En los 91 partidos, el marcador de cada set reconstruido desde el scout coincide con
la cabecera. El local de la cabecera coincide con el primer equipo del nombre del archivo en todos los
casos verificables. Indicadores generales: side-out 60,6 %, eficiencia de ataque 0,341, 5,78 acciones
por rally y 0,46 códigos verdes por rally.

## Advertencias importantes

- **Planteles del rival poco fiables.** En varios archivos, VolleyMetrics cargó en el equipo rival
  jugadores de otro equipo. Por ejemplo, Andrzej Wrona (Projekt Warszawa, #8) aparece en 5 partidos de
  PGE Skra Bełchatów, y Moustapha M'Baye aparece en Cuprum, Gdańsk, Jastrzębski y Nysa con tres
  números distintos. Por eso hay **74 filas con `revisar = True`** en `jugadores_unificados.csv`. Las
  estadísticas por equipo y por partido están bien, pero las estadísticas **por jugador** solo son
  confiables para los equipos con muchos partidos (Lublin, Olsztyn, Lviv, Katowice); para el resto,
  revisen el plantel antes de sacar conclusiones.
- **Fechas.** 85 cabeceras venían vacías y se usó la fecha del nombre del archivo de VolleyMetrics.
  En Canadá vimos que esa fecha puede estar en UTC; en Polonia (UTC+1/+2) eso solo movería partidos
  jugados pasada la medianoche, así que no debería afectar. Ver `partidos.fecha_corregida`.
- **3 partidos incompletos** (`partido_completo = False`): Olsztyn–Suwałki del 06/09 (pretemporada),
  GKS–Gdańsk del 16/11 y Lviv–Będzin del 30/11, con algún set sin terminar en el scout.
- **Nombres de equipo.** Vienen sin diacríticos, tal como los escribe VolleyMetrics (Belchatow,
  Kedzierzyn-Kozle, Rzeszow). Se corrigió "LUK Lubin" a "Bogdanka LUK Lublin" y se unificó Zawiercie
  ("Aluron Virtu CMC Zawiercie" → "Aluron CMC Warta Zawiercie").
- Algunos archivos se llaman solo `GKS(VM)` (sin el rival); el rival está en la cabecera.

## Jugadores para revisar

Ver el primer punto de las advertencias: las 74 filas con `revisar = True` vienen casi todas de
planteles copiados entre equipos, no de pases reales.
