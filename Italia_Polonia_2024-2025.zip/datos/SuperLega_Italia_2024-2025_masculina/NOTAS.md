# SuperLega italiana masculina 2024-25: notas del dataset

Resumen y problemas específicos de esta temporada. La estructura de las tablas, el diccionario de
columnas y el origen de los datos están en el [README principal](../../README.md).

## Resumen

| | 2024-25 |
|---|---|
| Archivos / partidos distintos | 332 / 166: casi todos los partidos vienen **dos veces**, scouteados por cada club (148 pares y 9 tríos) |
| Acciones | 164.329 (327.323 contando todas las copias) |
| Competiciones (`tipo_competicion`) | **SuperLega** 159 y **Playoff 5.º puesto** 7 |
| Fechas | 28/09/2024 → 10/05/2025 |
| Liga regular | **Completa**: 132 partidos, 12 equipos, ida y vuelta |
| Playoffs | Completos: cuartos (14 partidos), semifinales (8), 3.er puesto (1) y la final (4), que ganó **Itas Trentino 3-1 a Cucine Lube Civitanova** |
| Playoff 5.º puesto | Solo los 7 partidos de Allianz Milano (abril-mayo de 2025) |
| Equipos | Allianz Milano, Cisterna Volley, Cucine Lube Civitanova, Gas Sales Bluenergy Piacenza, Gioiella Prisma Taranto, Itas Trentino, Mint Vero Volley Monza, Rana Verona, Sir Susa Scai Perugia, Sonepar Padova, Valsa Group Modena, Yuasa Battery Grottazzolina |
| Scouters | Unos 15, uno o dos por club, más VolleyMetrics (16 archivos) |
| Acciones con coordenadas | 7 % (sí hay zonas en el 57 % de las acciones) |
| Rol de los jugadores | 99 % de los registros |
| Jugadores (nombres distintos → unificados) | 289 → 249 |

Es scout real, hecho por los analistas de los clubes. En los 332 archivos, el marcador de cada set
reconstruido desde el scout coincide con la cabecera. Indicadores generales: side-out 60,2 %,
eficiencia de ataque 0,345, 5,68 acciones por rally y 0,48 códigos verdes por rally.

## Advertencias importantes

- **Local y visitante: usen `local_real.csv`.** La mayoría de los analistas italianos pone a su
  propio equipo como local ("*") en la cabecera, también cuando juega de visitante. En **77 de los 166
  partidos** (la copia que quedó como principal), `equipo_local` no es el local real. El local real se
  sacó de la ciudad y el pabellón que traen los archivos (sección [3MORE]: "Civitanova Marche",
  "Porto San Giorgio" para Grottazzolina, "Assago" para Milano…), combinando las dos copias de cada
  partido. Cuando no había ciudad, se tomó del nombre de los archivos de VolleyMetrics. Con eso, la
  liga regular cierra exacta: cada par de equipos, una vez en cada cancha.

  ```python
  lr = pd.read_csv("local_real.csv")   # match_id, local_real, visitante_real, fuente, invertido
  p = p.merge(lr[["match_id", "local_real", "visitante_real", "invertido"]], on="match_id", how="left")
  ```

  Ojo: el lado "*" de las acciones sigue siendo el de la cabecera. Para estadísticas de localía, usen
  `local_real` para saber quién jugaba en casa.
- **Copias duplicadas.** Queda como principal la copia con más acciones (`es_principal`). Las copias
  de un mismo partido pueden diferir en el detalle (combinaciones, zonas, evaluaciones), porque son
  scouts de analistas distintos. Si comparan analistas o estilos de codificación, usen
  `grupo_duplicado` para encontrar las dos versiones.
- **Fase de la cabecera.** Cada analista la escribe distinto ("Andata", "a05", "Round robin
  Preliminary Round [1]", "Quarti", "PO-Q2", "Semifinale"…). No sirve para filtrar: usen las fechas
  (la liga regular termina el 02/03/2025) o el nombre del archivo.
- **Una semifinal con cabecera de otra competición**: el quinto Civitanova–Perugia (24/04) traía
  "CEV Volleyball Cup" en `competicion_original`; se corrigió a SuperLega.
- **Nombres de equipo.** Un analista usa solo la ciudad ("Modena 24-25", "Verona 24-25"…) y otros
  variantes del patrocinador ("Vero Volley Monza" / "Mint Vero Volley Monza"). Se unificó todo al
  nombre completo con patrocinador.
- **9 fechas corregidas**, sobre todo cabeceras vacías o en otro formato y copias de un mismo partido
  con un día de diferencia (ver `partidos.fecha_corregida`).
- **4 líneas descartadas** (`errores.csv`) con códigos mal escritos.

## Jugadores para revisar

En `jugadores_unificados.csv` hay 19 filas con `revisar = True`. Casi todas son pares de jugadores
del mismo equipo con los números cruzados en algún archivo (Kaziyski y Otsuka con el 1 y el 15 en
Milano, Ewert y Keita con el 3 y el 9 en Verona, Candellaro y Vagnetti con el 2 y el 4 en Perugia):
errores de plantel de algún analista. Mosca Leandro aparece en Monza y Verona.
