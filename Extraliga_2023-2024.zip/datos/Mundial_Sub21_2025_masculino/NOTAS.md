# Mundial Sub-21 masculino 2025 (FIVB): notas del dataset

Resumen y problemas específicos de este torneo. La estructura de las tablas, el diccionario de
columnas y el origen de los datos están en el [README principal](../../README.md).

## Resumen

| | 2025 |
|---|---|
| Archivos / partidos distintos | 77 / 77 (sin duplicados) |
| Acciones | 73.901 |
| Competición | `tipo_competicion = "Mundial Sub-21"` en todos los partidos |
| Fechas | 21/08/2025 → 31/08/2025 (3 archivos sin fecha) |
| Selecciones | 24 |
| Fases | Fase de grupos (58 de 60 partidos), los 8 octavos, los 4 cuartos y 7 partidos de clasificación. **No están las semifinales ni los partidos por medallas** |
| Scouters | 7, cada uno con su estilo; el principal ("ADR") hizo el 49 % de los archivos |
| Acciones con coordenadas | ≈ 0 % |
| Rol de los jugadores | 99,8 % de los registros |
| Jugadores (nombres distintos → unificados) | 356 → 302 |

En todos los archivos, el marcador de cada set reconstruido desde el scout coincide con la
cabecera (`partidos.validacion_marcador = OK`).

## Advertencias importantes

- **Es un torneo de selecciones**, no una liga: cada equipo tiene entre 4 y 9 partidos. Argentina y
  Turquía son las que más tienen (9).
- **Faltan partidos**: en la fase de grupos no están los partidos 052 y 057. Del cierre del torneo
  solo hay partidos de clasificación (077-082 y 097), sin semifinales ni final.
- **Varios scouters**: hay archivos de al menos 7 personas. Los códigos de combinación y tempo no son
  homogéneos, así que para comparar entre equipos usa fundamento + evaluación.
- **Nombres de selecciones**: venían escritos de unas 40 formas ("2025 U21 JAPAN", "TÃœRKIYE U21",
  "U21M USA WCH", "CINA", "UKRANIA"…). Se unificaron con el nombre del país en español más la
  categoría: Japón U21, Turquía U21, Estados Unidos U21, China U21, Ucrania U21, etc. El sufijo
  evita confundirlas con las selecciones de otras categorías si se combinan datasets.
- **3 archivos sin fecha** (`WC25 U21 039 CZE-BUL`, `051 CZE-JPN` y `055 CHN-EGY`): la cabecera venía
  vacía y el nombre del archivo no tiene fecha.
- Los 4 cuartos de final tienen otro formato de nombre (`29.08.25 QF …`) y otra competición en la
  cabecera. Se incluyeron igual, con `fase_original = "Quarter Final"`.
- Dos archivos tienen `fase_original = "FALTA"`, un texto que quedó en la cabecera. No afecta los datos.
- Casi no hay coordenadas: para el análisis espacial, usa `zona_inicio`/`zona_fin`.

## Jugadores para revisar

En `jugadores_unificados.csv` no hay filas con `revisar = True` en este torneo.
