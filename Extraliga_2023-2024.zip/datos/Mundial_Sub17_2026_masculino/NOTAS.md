# Mundial Sub-17 masculino 2026 (FIVB, Doha): notas del dataset

Resumen y problemas específicos de este torneo. La estructura de las tablas, el diccionario de
columnas y el origen de los datos están en el [README principal](../../README.md).

## Resumen

| | 2026 |
|---|---|
| Archivos / partidos distintos | 43 / 43 (sin duplicados) de los 46 que tuvo el torneo |
| Acciones | 41.080 |
| Competición | `tipo_competicion = "Mundial Sub-17"` en todos los partidos |
| Fechas | 19/08/2026 → 29/08/2026 |
| Selecciones | Las 20 que jugaron (Chequia, Japón, Puerto Rico y Estados Unidos se retiraron antes del torneo) |
| Fases | 28 de 30 partidos de grupos, 7 de 8 octavos, los 4 cuartos, las 2 semis, el bronce y la final |
| Scouters | 7, cada uno con su estilo; el principal (Patricio Dubois) hizo 27 de los 43 archivos |
| Acciones con coordenadas | ≈ 7 % (dispersas, ningún partido completo) |
| Rol de los jugadores | 99,7 % de los registros |
| Jugadores (nombres distintos → unificados) | 369 → 298 |

En todos los archivos, el marcador de cada set reconstruido desde el scout coincide con la
cabecera (`partidos.validacion_marcador = OK`) y todos los partidos están completos. Los resultados
de las semis, el bronce y la final coinciden con los oficiales (campeón Irán, 3-1 a Francia;
bronce Brasil, 3-1 a Argentina).

## Advertencias importantes

- **Faltan 3 partidos**: España–Egipto y Egipto–Turquía (grupo D) y el octavo de final que
  corresponde al archivo n.º 33.
- **La fase de la cabecera no es fiable.** `fase_original` viene en varios idiomas y a veces mal:
  China Taipéi–Argelia dice "Grupo C" (es del E), Catar–Túnez dice "Grupo D" (es del A), la semi
  Argentina–Irán dice "Cuartos de Final", la final dice "Pool C", el octavo Egipto–Pakistán dice
  "Finale" (y su archivo, "Grupo D"), y dos archivos la traen vacía. **Usen el número del archivo**,
  que sí sigue el orden del torneo:

  ```python
  num = p["archivo"].str.extract(r"^&(\d+)")[0].astype(int)
  p["fase"] = pd.cut(num, [0, 30, 38, 42, 44, 45, 46],
                     labels=["Grupos", "Octavos", "Cuartos", "Semifinal", "Bronce", "Final"])
  ```

- **Varios scouters**: hay archivos de al menos 7 personas (4 sin nombre en la cabecera). Los
  códigos de combinación y tempo no son homogéneos, así que para comparar entre equipos usen
  fundamento + evaluación.
- **Nombres de selecciones**: venían escritos de unas 30 formas ("ROMANIA U17", "ESPA?A U17",
  "U17 Qatar national team", "ALG U 17 2026", "TÜRK?YE U17"…). Se unificaron con el nombre del país
  en español más la categoría: Rumania U17, España U17, Catar U17, Argelia U17, Turquía U17,
  China Taipéi U17, etc. El sufijo evita confundirlas con las del Mundial Sub-21 si se combinan
  datasets.
- **Una fecha distinta en el nombre**: el octavo Brasil–India dice 27-8-26 en el nombre del archivo y
  25/08 en la cabecera. Se dejó la fecha de la cabecera, que coincide con el resto de los octavos.
- **2 líneas descartadas** (`errores.csv`): dos acciones con el número de jugador mal escrito
  ("X5", "X1").
- Casi no hay coordenadas: para el análisis espacial, usen `zona_inicio`/`zona_fin`.

## Jugadores para revisar

En `jugadores_unificados.csv` hay 3 filas con `revisar = True`, todas de Rumania: Balau Tudor (#15 y
#21) y Onute David y Onute Luca, que aparecen con los números 10 y 19 intercambiados
según el archivo. Conviene revisarlos a mano.
