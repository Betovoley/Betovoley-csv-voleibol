# Extraliga checa masculina 2023-24 (ČEZ Extraliga mužů): notas del dataset

Resumen y problemas específicos de esta temporada. La estructura de las tablas, el diccionario de
columnas y el origen de los datos están en el [README principal](../../README.md).

## Resumen

| | 2023-24 |
|---|---|
| Archivos / partidos distintos | 162 / 162 (sin duplicados) |
| Acciones | 151.989 |
| Competición | `tipo_competicion = "Extraliga"` en todos los partidos (fase regular y playoffs) |
| Fechas | 19/10/2023 → 25/04/2024 |
| Fase regular | **Completa**: 156 partidos, los 13 equipos contra todos, ida y vuelta (24 partidos por equipo) |
| Playoffs | 6 partidos: 2 de la serie Brno–Beskydy y los 4 de la final, que ganó České Budějovice 3-1 a Praha |
| Equipos | Beskydy, Benátky nad Jizerou, Brno, České Budějovice, Karlovarsko, Kladno, Liberec, Odolena Voda, Ostrava, Praha, Příbram, Ústí nad Labem, Zlín |
| Scouters | Unos 15; los principales son Adam Šimonek (52 archivos), Ondrej Smolka (33), Petr Sezemsky (21) y Zdenek Sklenar (~24) |
| Acciones con coordenadas | 0 % (sí hay zonas en el 60 % de las acciones) |
| Rol de los jugadores | 99,5 % de los registros |
| Jugadores (nombres distintos → unificados) | 207 → 206 |

Es scout real de la federación checa (Český volejbalový svaz). Indicadores generales: side-out
58,1 %, eficiencia de ataque 0,286, 5,55 acciones por rally y 0,47 códigos verdes por rally.
En 159 de los 162 partidos, el marcador de cada set reconstruido desde el scout coincide con la
cabecera.

## Advertencias importantes

- **Playoffs mezclados con la fase regular.** `fase_original` dice "Main Round" en los 162 archivos,
  también en los playoffs. Para separarlos, usen el nombre del archivo (los de playoffs terminan en
  `EX-M-I`):

  ```python
  p["playoff"] = p["archivo"].str.contains("EX-M-I")
  ```

- **Fechas en formato estadounidense.** Las cabeceras traen la fecha como mes/día/año
  (12/07/2023 = 7 de diciembre). El conversor lo detecta para el dataset completo: ninguna cabecera
  tiene el primer número mayor que 12 y 100 tienen el segundo. Así se leyeron bien también las
  ambiguas.
- **Nombres de archivo equivocados en 2 partidos.** `&3049_Brno-Liberec` es en realidad
  České Budějovice–Odolena Voda (3-0) y `&3071_Beskydy-Usti` es České Budějovice–Příbram (3-0): los
  nombres repiten los de los archivos 3047 y 3073. Se usaron los equipos y el resultado de la cabecera, que cierran el calendario
  completo. Un tercer archivo se llama "- Copy" (`&3120_Zlin-CeskeBudejovice`), pero no está
  duplicado.
- **Codificación checa.** 138 archivos están en cp1250 (Windows de Europa central). El conversor lo
  detecta comparando los nombres con la copia Unicode que guarda DataVolley, así que Příbram,
  České Budějovice, Ústí, etc. salen bien escritos. Los nombres de jugadores en `apellido`/`nombre`
  vienen sin diacríticos desde el origen (Janecka, no Janečka).
- **Nombres de equipo.** Venían abreviados y de varias formas ("O. Voda", "Ústí n. L.", "Ústí N. L.",
  "Benátky n. J."); se normalizaron al nombre de la ciudad completo.
- **Scouters con caracteres rotos.** En unos 20 archivos el nombre del scouter viene dañado desde el
  origen (por ejemplo "Zden�k �OLC") y el mismo scouter aparece escrito de varias formas ("Adam
  Šimonek"/"Adam Simonek", "Sklenar Zdenek"/"Zdenek Sklenar"…). No usen `scouter` para agrupar sin
  limpiarlo antes.
- **3 sets con un punto de diferencia** entre la cabecera y el scout: Benátky–Praha (3074),
  Ostrava–Beskydy (3040) y Benátky–Karlovarsko (3041). Ver `partidos.validacion_marcador`.
- **1 línea descartada** (`errores.csv`): una acción con el número de jugador mal escrito ("X8").
- Sin coordenadas: para el análisis espacial, usen `zona_inicio`/`zona_fin`.

## Jugadores para revisar

En `jugadores_unificados.csv` hay 16 filas con `revisar = True`. Casi todas son jugadores que
aparecen con dos números de camiseta en el mismo equipo (por ejemplo, Velat Ondrej con el 12, el 13
y el 18 en České Budějovice). Probablemente es un error del scout en algún partido. Dos son pases
a mitad de temporada: Srb Jiri (Benátky → Odolena Voda) y Hysky Tomas (Kladno → Ústí).
