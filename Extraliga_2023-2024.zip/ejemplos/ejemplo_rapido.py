"""Ejemplo mínimo: cargar un dataset y calcular dos indicadores clásicos.

Uso:  python ejemplos/ejemplo_rapido.py [nombre_de_carpeta_en_datos]
      (sin argumento usa la Superliga 2024-25)
"""
import sys
from pathlib import Path
import pandas as pd

RAIZ = Path(__file__).resolve().parent.parent
carpeta = sys.argv[1] if len(sys.argv) > 1 else "Superliga_Brasilera_2024-2025_masculina"
DATOS = RAIZ / "datos" / carpeta
LIGA = ("Superliga" if "Superliga" in carpeta else "NCAA" if "NCAA" in carpeta
        else "Mundial Sub-21" if "Mundial_Sub21" in carpeta
        else "Mundial Sub-17" if "Mundial_Sub17" in carpeta
        else "U Sports" if "U_Sports" in carpeta
        else "Extraliga" if "Extraliga" in carpeta else "Liga (LVA)")

acc = pd.read_csv(DATOS / "acciones.csv.gz", low_memory=False)

# 1) Un archivo por partido y solo la liga principal
liga = acc[acc["es_principal"] & (acc["tipo_competicion"] == LIGA)]

# 2) Eficiencia de ataque por equipo: (puntos - errores - bloqueados) / total
ataques = liga[liga["fundamento_cod"] == "A"]
ef = (ataques.groupby("equipo_nombre")["evaluacion_cod"]
      .agg(total="size",
           puntos=lambda s: (s == "#").sum(),
           errores=lambda s: (s == "=").sum(),
           bloqueados=lambda s: (s == "/").sum()))
ef["eficiencia"] = (ef.puntos - ef.errores - ef.bloqueados) / ef.total
print(f"{carpeta}: eficiencia de ataque\n", ef.sort_values("eficiencia", ascending=False).round(3))

# 3) Side-out: % de rallies ganados cuando el equipo recibe
rec = liga[liga["fundamento_cod"] == "R"].drop_duplicates(["match_id", "rally_n"])
so = rec.groupby("equipo_nombre")["gana_rally_equipo_accion"].mean()
print("\n% side-out por equipo\n", (so * 100).round(1).sort_values(ascending=False))
