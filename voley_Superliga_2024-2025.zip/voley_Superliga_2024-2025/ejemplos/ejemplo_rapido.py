"""Ejemplo mínimo: cargar el dataset y calcular dos indicadores clásicos."""
from pathlib import Path
import pandas as pd

DATOS = next((Path(__file__).resolve().parent.parent / "datos").iterdir())  # carpeta de la temporada

acc = pd.read_csv(DATOS / "acciones.csv.gz", low_memory=False)

# 1) Quedarse con un archivo por partido y solo con la Superliga
liga = acc[acc["es_principal"] & (acc["tipo_competicion"] == "Superliga")]

# 2) Eficiencia de ataque por equipo: (puntos - errores - bloqueados) / total
ataques = liga[liga["fundamento_cod"] == "A"]
ef = (ataques.groupby("equipo_nombre")["evaluacion_cod"]
      .agg(total="size",
           puntos=lambda s: (s == "#").sum(),
           errores=lambda s: (s == "=").sum(),
           bloqueados=lambda s: (s == "/").sum()))
ef["eficiencia"] = (ef.puntos - ef.errores - ef.bloqueados) / ef.total
print(ef.sort_values("eficiencia", ascending=False).round(3))

# 3) Side-out: % de rallies ganados cuando el equipo recibe
rec = liga[liga["fundamento_cod"] == "R"].drop_duplicates(["match_id", "rally_n"])
so = rec.groupby("equipo_nombre")["gana_rally_equipo_accion"].mean()
print("\n% side-out por equipo\n", (so * 100).round(1).sort_values(ascending=False))
