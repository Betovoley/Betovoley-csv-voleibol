# Extraliga checa masculina 2024-25 (ČEZ Extraliga mužů): notas del dataset

Resumen y problemas específicos de esta temporada. La estructura de las tablas, el diccionario de
columnas y el origen de los datos están en el [README principal](../../README.md).

## Resumen

| | 2024-25 |
|---|---|
| Archivos / partidos distintos | 185 / 185 (sin duplicados) |
| Acciones | 182.391 |
| Competición | `tipo_competicion = "Extraliga"` en todos los partidos (fase regular y playoffs) |
| Fechas | 26/09/2024 → 04/05/2025 |
| Fase regular | 155 de 156 partidos (13 equipos, ida y vuelta); falta Ústí nad Labem–Karlovarsko |
| Playoffs | 30 partidos: 5 de la ronda previa, 14 de cuartos, 6 de semis y los 5 de la final, que ganó Praha 3-2 a Karlovarsko |
| Equipos | Los mismos 13 de 2023-24 |
| Scouters | Unos 15; los principales son Adam Šimonek (45 archivos), Ondra/Ondrej Smolka (37), Agustín Briscioli (35, analista de Praha) y Zdenek Sklenar (~24); 19 archivos sin nombre |
| Acciones con coordenadas | < 1 % (sí hay zonas en el 59 % de las acciones) |
| Rol de los jugadores | 99,7 % de los registros |
| Jugadores (nombres distintos → unificados) | 207 → 206 |

Es scout real de la federación checa. Indicadores generales: side-out 58,2 %, eficiencia de ataque
0,283, 5,74 acciones por rally y 0,46 códigos verdes por rally. En los 185 partidos, el marcador de
cada set reconstruido desde el scout coincide con la cabecera.

## Advertencias importantes

- **Local y visitante invertidos en 15 partidos de Praha.** El analista de Praha (Briscioli) pone
  siempre a su equipo como local ("*") en la cabecera, también cuando juega de visitante. En esos 15
  archivos, `equipo_local` es Praha pero el local real es el rival. El local real está en el nombre
  del archivo (`..._BEN-PRA.dvw` = Benátky local). Para análisis de localía, corríjanlo así:

  ```python
  cod = p["archivo"].str.extract(r"_([A-Z]{3})-([A-Z]{3})")
  invertido = (p["equipo_local"] == "Praha") & (cod[1] == "PRA")
  p["local_real"] = p["equipo_local"].where(~invertido, p["equipo_visitante"])
  ```

  Los datos del scout no cambian: el lado "*" sigue siendo Praha en todas las acciones de esos
  archivos.
- **Fechas en dos formatos mezclados.** 46 cabeceras están en día/mes, 70 en mes/día y 69 son
  ambiguas (por ejemplo 05/04/2025). El conversor resolvió las ambiguas con los números de partido,
  que siguen el orden del calendario: eligió la lectura que encaja entre el partido anterior y el
  siguiente. Hay 37 fechas corregidas, todas explicadas en `partidos.fecha_corregida`. Ningún equipo
  queda con dos partidos el mismo día. El único salto de calendario que queda es Kladno–Ústí del
  20/02/2025, con fecha sin ambigüedad: parece un partido reprogramado.
- **Fase de la cabecera.** `fase_original` distingue la fase regular ("Main Round - EX-M-24/25") de los
  playoffs ("Main Round - EX-M 24/25 - I"). La ronda de playoff está en el nombre del archivo
  (`PLAY_OFF_8` previa, `_4` cuartos, `_2` semis, `_1` final).
- **Un partido incompleto**: Ústí–Ostrava (11150) solo tiene 2 sets scouteados (25-19 y 20-21).
- **Nombres de equipo.** Además de las abreviaturas del año anterior, venían "VK Lvi Praha",
  "VK Dukla Liberec", "Fatra Zlín", "Volejbal Brno", "Kladno volejbal cz", "VK Ostrava"…; todos se
  normalizaron al nombre de la ciudad, igual que en 2023-24, para que se puedan combinar las dos
  temporadas.
- **Scouters con nombres rotos o en varias formas** ("Tom� Va�k�t", "Briscioli Agustin" / "Agustin
  Ignacio Briscioli"…). Límpienlo antes de agrupar por `scouter`.
- Sin coordenadas: para el análisis espacial, usen `zona_inicio`/`zona_fin`.

## Jugadores para revisar

En `jugadores_unificados.csv` hay 20 filas con `revisar = True`. Casi todas son jugadores con dos o
tres números de camiseta en el mismo equipo (por ejemplo, Waclaw Daniel con el 1, el 23 y el 27 en
Brno), probablemente por errores de scout. Krisko Michal aparece en Beskydy y en České Budějovice
(posible pase).
