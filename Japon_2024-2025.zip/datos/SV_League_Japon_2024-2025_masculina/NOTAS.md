# SV.League japonesa masculina 2024-25: notas del dataset

Resumen y problemas específicos de esta temporada. La estructura de las tablas, el diccionario de
columnas y el origen de los datos están en el [README principal](../../README.md).

## Resumen

| | 2024-25 |
|---|---|
| Archivos / partidos distintos | 223 / 222 (1 archivo excluido, sin duplicados) |
| Acciones | 233.859 |
| Competición | `tipo_competicion = "SV League"` en todos los partidos |
| Fechas | 11/10/2024 → 26/04/2025 |
| Liga regular | **Completa**: 220 partidos, 10 equipos con 44 partidos cada uno (fines de semana de dos partidos contra el mismo rival) |
| Playoffs | Solo la semifinal JTEKT Stings Aichi–Osaka Bluteon (2 partidos, ganó JTEKT). No están la otra semifinal ni la final |
| Equipos | JTEKT Stings Aichi, Osaka Bluteon, Suntory Sunbirds Osaka, Nippon Steel Sakai Blazers, Toray Arrows Shizuoka, Wolfdogs Nagoya, Hiroshima Thunders, Tokyo Great Bears, Voreas Hokkaido, VC Nagano Tridents |
| Scouters | Dos: Shogo Nukui (110 archivos, también como "Nukui Shogo") y Takuma Yoshida (109); 3 de Ken Ikehara. Archivos de la federación japonesa (Japan Volleyball Association) |
| Acciones con coordenadas | 0 % (sí hay zonas en el 55 % de las acciones) |
| Rol de los jugadores | 100 % de los registros |
| Jugadores (nombres distintos → unificados) | 188 → 184 |

Es scout real y es uno de los datasets más limpios del repo. Todas las fechas de cabecera vienen en
año/mes/día, sin ambigüedad; no hay fechas corregidas ni jugadores para revisar. En los 222 partidos,
el marcador de cada set reconstruido desde el scout coincide con la cabecera. Indicadores generales:
side-out 62,8 %, eficiencia de ataque 0,371 (la más alta del repo), 6,10 acciones por rally y 0,42
códigos verdes por rally.

## Advertencias importantes

- **Un archivo excluido**: `&251017_FM_BLZvsSUN 1-3` es un amistoso del 17/10/2025, de la pretemporada
  2025-26, con los planteles nuevos (por eso varios jugadores aparecían en dos equipos). Está en
  `errores.csv`.
- **Fase.** `fase_original` dice la vuelta de la liga regular ("Regular Round 1st" … "Regular Round
  6th") o "Semi Final". Las vueltas 5.ª y 6.ª tienen la mitad de partidos (21 y 20), porque así es el
  calendario de la liga: no faltan partidos.
- **Nombres de equipo.** Se quitó el sufijo de temporada ("WOLFDOGS Nagoya 2024-25") y se unificó
  "TOKYO Great Bears" / "Tokyo Great Bears". Se mantuvo el estilo de la liga, con el patrocinador en
  mayúsculas (JTEKT, SUNTORY, TORAY…).
- **Scouter escrito de dos formas** ("Shogo Nukui" / "Nukui Shogo"). Límpienlo antes de agrupar por
  `scouter`.
- Sin coordenadas: para el análisis espacial, usen `zona_inicio`/`zona_fin`.

## Jugadores para revisar

En `jugadores_unificados.csv` no hay filas con `revisar = True`.
