# Rusia 2025-26 masculino (Superliga y Copa Victoria): notas del dataset

Resumen y problemas específicos de este dataset. La estructura de las tablas, el diccionario de
columnas y el origen de los datos están en el [README principal](../../README.md).

> **Muestra chica, no una temporada.** Son 13 partidos de comienzo de temporada, casi todos de
> Zenit San Petersburgo y Lokomotiv Novosibirsk. Sirven para mirar esos dos equipos o como ejemplo
> de otra liga, no para comparar equipos de la Superliga rusa.

## Resumen

| | 2025-26 |
|---|---|
| Archivos / partidos distintos | 13 / 13 (sin duplicados) |
| Acciones | 12.369 |
| Competiciones | `tipo_competicion`: **Copa Victoria** (8 partidos, septiembre-octubre de 2025, de los que 2 son del final four) y **Superliga Rusa** (5 partidos de las jornadas 1 a 4) |
| Fechas | 15/09/2025 → 01/11/2025 |
| Equipos | 9; Zenit San Petersburgo juega 9 partidos y Lokomotiv Novosibirsk 6, el resto 1 a 3 |
| Scouters | Dmitriy Feschenko (Zenit San Petersburgo, 7), Sosnin Dmitry (2, final four) y otros |
| Acciones con coordenadas | 0 % (sí hay zonas en el 58 % de las acciones) |
| Rol de los jugadores | 100 % de los registros |
| Jugadores (nombres distintos → unificados) | 144 → 136 |

Es scout real; los nombres ya vienen transliterados al alfabeto latino (Babkevich, Shishkin…). En los
13 partidos, el marcador de cada set reconstruido desde el scout coincide con la cabecera.
Indicadores generales: side-out 62,3 %, eficiencia de ataque 0,339 y 5,57 acciones por rally. Por el
tamaño de la muestra, tómenlos solo como referencia.

## Advertencias importantes

- **Local y visitante invertidos en 3 partidos de Zenit San Petersburgo.** Su analista pone a su
  equipo como local ("*") también cuando juega de visitante: `lon-spb` (16/09 y 26/09, en Novosibirsk)
  y `mgt-spb` (19/10, en Moscú). El local real está en el nombre del archivo: el primer código es el
  local.
- **Una fecha corregida.** El segundo Lokomotiv–Zenit de la Copa Victoria traía en la cabecera el
  25/09/**2026**. Se corrigió al año de inicio de temporada (25/09/2025), pero el nombre del archivo
  dice 26/09, así que puede ser del día siguiente.
- **Fase de la cabecera** sin un formato común: "1st round", "2d", "Final", "Regular", "Regular season",
  "02"… Para separar la fase de grupos de la Copa Victoria del final four, usen el nombre del archivo
  (`vcup25` frente a `vcup25.f`).
- **Final four de la Copa Victoria**: hay dos partidos de Zenit San Petersburgo, ambos marcados como
  "Final" en la cabecera: contra Zenit Kazán el 11/10 (ganó 3-2) y contra Dinamo Moscú el 12/10
  (perdió 2-3). La cabecera no dice cuál es semifinal y cuál final o tercer puesto.
- Sin coordenadas: para el análisis espacial, usen `zona_inicio`/`zona_fin`.

## Jugadores para revisar

En `jugadores_unificados.csv` no hay filas con `revisar = True`.
