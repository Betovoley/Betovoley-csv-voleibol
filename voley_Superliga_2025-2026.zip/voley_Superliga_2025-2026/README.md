# Datos de scout de voleibol (DataVolley → CSV)

Archivos DataVolley (`.dvw`) convertidos a CSV para trabajar en Python/pandas.
Temporada 2025-26 de la Superliga Brasileña masculina y otras competiciones de esa temporada.

```
datos/
  Superliga_Brasilera_2025-2026_masculina/
    acciones.csv.gz            una fila por acción de scout (CSV comprimido)
    partidos.csv               una fila por archivo .dvw
    sets.csv                   una fila por set
    jugadores.csv              planteles de cada archivo, con jugador_uid
    jugadores_unificados.csv   un jugador por fila, con sus variantes de nombre
    errores.csv                líneas del scout que no se pudieron interpretar (vacío = todo OK)
scripts/dvw_a_csv.py           el conversor
ejemplos/ejemplo_rapido.py
```

`acciones` va comprimido porque GitHub no acepta archivos de más de 100 MB
(las temporadas grandes superan los 50 MB sin comprimir). pandas lo lee directamente:

```python
import pandas as pd
ruta = "datos/Superliga_Brasilera_2025-2026_masculina/"
acc = pd.read_csv(ruta + "acciones.csv.gz", low_memory=False)

acc = acc[acc["es_principal"]]                       # SIEMPRE: quita partidos duplicados
liga = acc[acc["tipo_competicion"] == "Superliga"]
```

Las tablas se unen por `match_id`. Para seguir a un jugador entre partidos, usa
`jugador_uid` (está en `acciones` y en `jugadores`) y no el nombre ni el número.

Para convertir un zip nuevo (el nombre del zip con `AAAA-AAAA` se usa para validar fechas):

```bash
pip install -r requirements.txt
python scripts/dvw_a_csv.py Liga_X_2024-2025.zip datos/Liga_X_2024-2025
```

## Resumen

| | 2025-26 |
|---|---|
| Archivos / partidos distintos | 215 / 215 (sin duplicados) |
| Acciones | 211.333 |
| Superliga | 148: **fase regular completa** (132 partidos, 22 por equipo) + 10 de cuartos, 5 de semis y la final |
| Otras competiciones | Torneio Mineiro 24, Sudamericano de Clubes 15, Mundial de Clubes 11, Copa do Brasil 6, amistosos 6, Campeonato Paulista 4, Supercopa do Brasil 1 |
| Equipos de Superliga | Sada Cruzeiro, Minas, Vôlei Renata, Praia Clube, Suzano, Guarulhos, Goiás, Azulim Monte Carmelo, SESI, JF Vôlei, Joinville, São José |
| Scouters | 10; Betovoley hizo el 93 % de los archivos |
| Acciones con coordenadas | ~0 % |
| Jugadores (nombres distintos → unificados) | 460 → 437 |

En todos los archivos, el marcador de cada set reconstruido desde el scout coincide con
la cabecera (`partidos.validacion_marcador = OK`).

## Advertencias importantes

**Generales**
- **La fase regular de la Superliga está completa**: los 12 equipos tienen sus 22 partidos, así
  que se pueden comparar equipos sin normalizar. En los playoffs y en las otras competiciones,
  la cantidad de partidos por equipo sí es desigual: Sada Cruzeiro aparece en 49 archivos.
- **No es solo la Superliga**: filtra por `tipo_competicion`.
- **Las otras competiciones están incompletas**: del Mineiro, el Paulista, el Sudamericano y el
  Mundial solo están los partidos que se scoutearon, no el torneo entero.
- **Convenciones de scout**: casi todo es de un mismo scouter, así que los códigos son bastante
  homogéneos. Igual, para comparar con otras ligas, apóyate en fundamento + evaluación.
- Nombres de equipo normalizados en `equipo_local`/`equipo_nombre` (p. ej. "AZULIM/SICOOB
  ARACOOP/MONTE CARMELO" → Azulim Monte Carmelo); los originales quedan en `equipo_*_original`.

**Específicas de 2025-26**
- **Qué se incluyó**: el zip original traía 313 archivos. Solo entraron las competiciones de esta
  temporada en Brasil y las internacionales de clubes: Superliga, Torneio Mineiro, Copa do Brasil,
  Supercopa, Campeonato Paulista, Sudamericano, Mundial de Clubes y amistosos (215 archivos).
  **No se incluyeron** los entrenamientos ni los partidos de otras ligas (Italia, Japón, Polonia,
  Portugal, Francia, Argentina, Champions League, Copa Joinville y un partido universitario de Canadá).
- Los dos .zip que venían dentro del zip original (`Scout.zip` y `superliga2526 ok.zip`) son
  copias de respaldo de los mismos .dvw. Los sueltos son iguales o más nuevos, así que se usaron esos.
- **Mundial de Clubes 2025**: además de los partidos de Sada, incluye partidos de Perugia, Osaka
  Bluteon, Aluron, Vôlei Renata, Praia, Al Rayyan y Swehly.
- **Sudamericano de Clubes 2026**: incluye equipos argentinos (Ciudad, Defensores, San Lorenzo),
  Lagomar (URU), Murano (CHI) y Deportivo JML (ECU).
- **SESI** queda con ese nombre, sin "-SP".
- Las 19 acciones sin jugador identificado son casi todas del Mineiro Mogi–Sada (17).
- Una línea del scout de un amistoso Swehly–Mogi no se pudo interpretar y no se incluyó.
- Casi no hay coordenadas: para el análisis espacial, usa `zona_inicio`/`zona_fin`.


## Unificación de jugadores

El mismo jugador aparece escrito de varias formas según el scouter (`HILLING MATHEW` /
`Hilling Matthew Alexander`, `WLODARSKI` / `Wlqdarski`, `Brandon Michael` sin apellido…).
`jugador_uid` agrupa esas variantes, siempre dentro del mismo equipo, con estas reglas:

1. **Mismo número de camiseta**: se unen si todas las palabras del nombre más corto aparecen
   en el otro (se aceptan errores de tipeo), con el apellido coincidente o al menos 2 palabras.
2. **Distinto número**: se unen solo si coinciden el apellido y todas las palabras del nombre
   más corto (al menos 2). Estos casos quedan con `revisar = True`.
3. **Entre equipos** (traspasos, o jugadores de la selección chilena que después jugaron
   en Ciudad): se unen solo con nombre idéntico. También quedan con `revisar = True`.
4. Nunca se unen dos registros que aparecen en el mismo partido.

`jugadores_unificados.csv` muestra, para cada `jugador_uid`, el nombre canónico, los
equipos, los números, todas las variantes encontradas y el motivo de la unión. **Conviene
revisar a mano las filas con `revisar = True`**: son 8. Si
alguna unión está mal, avísenme y se ajusta la regla o se agrega una excepción.

El `jugador_uid` es el nombre canónico en formato texto (`RATTRAY_BRANDON_MICHAEL`).
Si dos jugadores distintos quedan con el mismo nombre, se le agrega el equipo al uid.
Entre temporadas el uid **suele** coincidir, pero no está garantizado: el nombre canónico
depende de cómo lo escribió cada scouter.

## Diccionario de `acciones.csv.gz`

| Columna | Descripción |
|---|---|
| `match_id`, `accion_id` | Identificador del partido (estable, derivado del nombre de archivo) y de la fila |
| `fecha`, `tipo_competicion`, `es_principal` | Copiados de `partidos.csv` para filtrar sin hacer merge |
| `set`, `rally_n` | Set y número de rally dentro del partido |
| `marcador_local`, `marcador_visitante` | Marcador **antes** del rally |
| `marcador_*_despues`, `punto_ganado_por` | Marcador después del rally y quién lo ganó (`local`/`visitante`) |
| `gana_rally_equipo_accion` | True si el equipo que hizo la acción ganó ese rally |
| `equipo`, `equipo_nombre`, `rival_nombre` | `local`/`visitante` y nombres normalizados |
| `jugador_numero`, `jugador_nombre` | Camiseta y nombre tal como figura en ese archivo |
| `jugador_uid`, `jugador_canonico` | Identificador unificado y nombre canónico del jugador |
| `jugador_rol` | Armador, Punta, Opuesto, Central, Líbero |
| `fundamento_cod` / `fundamento` | S Saque, R Recepción, A Ataque, B Bloqueo, D Defensa, E Armado, F Free ball, & Código verde |
| `tipo_cod` / `tipo` | Saque/recepción: H flotado, M salto flotado, Q salto potente, T topspin. Resto (tempo): H alta, M media, Q rápida, T tensa, U súper, N slide, O otra |
| `evaluacion_cod` / `evaluacion` | `#` `+` `!` `-` `/` `=` (ver tabla abajo) |
| `combinacion` | Código de combinación de ataque (A) |
| `llamada_armador`, `objetivo_armado` | Llamada del armador (K1, K7…) y destino del armado (F, B, C, P, S) en E |
| `zona_inicio`, `zona_fin`, `subzona_fin` | Zonas 1-9 y subzona A-D |
| `subtipo` / `subtipo_desc` | En ataque: H potente, P colocado, T toque |
| `num_jugadores` | En ataque: número de bloqueadores |
| `especial`, `custom` | Código especial y campo libre del scouter (sin traducir) |
| `equipo_saque`, `fase_juego` | Quién sacó en el rally; `Side-out` si la acción es del equipo receptor, `Break point` si es del que sacó |
| `fase_ataque_raw`, `fase_punto_raw` | Campos originales de DataVolley (r = tras recepción, p = transición; s/p en el punto) |
| `rotacion_local`, `rotacion_visitante` | Zona donde está el armador (1-6) |
| `coord_*`, `inicio_x/y`, `medio_x/y`, `fin_x/y` | Coordenada DataVolley y su posición en la grilla (x 1-100, y 1-101) |
| `local_p1..p6`, `visit_p1..p6` | Número de camiseta en cada zona en ese momento |
| `hora`, `video_seg` | Hora del registro y segundo del video |
| `codigo`, `linea_scout` | Código original y número de línea en el .dvw (para auditar) |

### Evaluaciones (convención estándar de DataVolley)

| | `#` | `+` | `!` | `-` | `/` | `=` |
|---|---|---|---|---|---|---|
| Saque | Ace | Positivo | OK, sin primer tiempo | Negativo | Rival no puede atacar | Error |
| Recepción | Perfecta | Positiva | OK, sin primer tiempo | Negativa | Mala / devuelta | Error |
| Ataque | Punto | Positivo | Bloqueado para reataque | Negativo | Bloqueado (punto rival) | Error |
| Bloqueo | Punto | Positivo | Pobre | Negativo | Invasión | Error |
| Defensa | Perfecta | Positiva | OK | Negativa | Pasa al otro campo | Error |
| Armado | Perfecto | Positivo | OK | Negativo | Malo | Error |

**Código verde (`&`)**: puntos o errores registrados sin un fundamento técnico
(penales, rotación, etc.): `#` = punto para el equipo y `=` = error del equipo.

> Las descripciones siguen la convención estándar. Algunos scouters redefinen
> evaluaciones, así que, ante cualquier duda, se puede revisar el `codigo` original.
