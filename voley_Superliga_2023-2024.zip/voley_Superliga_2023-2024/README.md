# Datos de scout de voleibol (DataVolley → CSV)

Archivos DataVolley (`.dvw`) convertidos a CSV para trabajar en Python/pandas.
Temporada 2023-24 de la Superliga Brasileña masculina y otras competiciones de esa temporada.

```
datos/
  Superliga_Brasilera_2023-2024_masculina/
    acciones.csv.gz            una fila por acción de scout (CSV comprimido)
    partidos.csv               una fila por archivo .dvw
    sets.csv                   una fila por set
    jugadores.csv              planteles de cada archivo, con jugador_uid
    jugadores_unificados.csv   un jugador por fila, con sus variantes de nombre
    errores.csv                líneas del scout que no se pudieron interpretar (vacío = todo OK)
scripts/dvw_a_csv.py           el conversor
ejemplos/ejemplo_rapido.py
```

`acciones` va comprimido porque GitHub no acepta archivos de más de 100 MB
(las temporadas grandes superan los 50 MB sin comprimir). pandas lo lee directamente:

```python
import pandas as pd
ruta = "datos/Superliga_Brasilera_2023-2024_masculina/"
acc = pd.read_csv(ruta + "acciones.csv.gz", low_memory=False)

acc = acc[acc["es_principal"]]                       # SIEMPRE: quita partidos duplicados
liga = acc[acc["tipo_competicion"] == "Superliga"]
```

Las tablas se unen por `match_id`. Para seguir a un jugador entre partidos, usa
`jugador_uid` (está en `acciones` y en `jugadores`) y no el nombre ni el número.

Para convertir un zip nuevo (el nombre del zip con `AAAA-AAAA` se usa para validar fechas):

```bash
pip install -r requirements.txt
python scripts/dvw_a_csv.py Liga_X_2024-2025.zip datos/Liga_X_2024-2025
```

## Resumen

| | 2023-24 |
|---|---|
| Archivos / partidos distintos | 248 / 248 (sin duplicados) |
| Acciones | 230.647 |
| Superliga | 150: **fase regular completa** (132 partidos) + 12 de cuartos, 5 de semis y la final |
| Otras competiciones | Torneio Mineiro 32, Campeonato Paulista 30, Sudamericano de Clubes 14, Copa do Brasil 7, Mundial de Clubes 6, amistosos 5, Campeonato Catarinense 3, Supercopa 1 |
| Equipos de Superliga | SESI, Vôlei Renata, Joinville, Guarulhos, Minas, Farma Conde São José, Araguari, Sada Cruzeiro, Montes Claros, Azulim Monte Carmelo, Suzano, APAN Blumenau |
| Scouters | 5; Betovoley hizo el 98 % de los archivos |
| Acciones con coordenadas | ~1 % |
| Jugadores (nombres distintos → unificados) | 599 → 451 |

El marcador de cada set reconstruido desde el scout coincide con la cabecera en todos los
archivos, salvo en uno (ver abajo).

## Advertencias importantes

**Generales**
- **La fase regular de la Superliga está completa**: los 12 equipos tienen sus 22 partidos, así
  que se pueden comparar equipos sin normalizar. En los playoffs y en las otras competiciones,
  la cantidad de partidos por equipo sí es desigual.
- **No es solo la Superliga**: filtra por `tipo_competicion`.
- **Las otras competiciones están incompletas**: del Mineiro, el Paulista, el Sudamericano y el
  Mundial solo están los partidos que se scoutearon, no el torneo entero.
- **Convenciones de scout**: casi todo es de un mismo scouter, así que los códigos son bastante
  homogéneos. Igual, para comparar con otras ligas, apóyate en fundamento + evaluación.
- Nombres de equipo normalizados en `equipo_local`/`equipo_nombre` (p. ej. "AZULIM/SICOOB
  ARACOOP/MONTE CARMELO" → Azulim Monte Carmelo); los originales quedan en `equipo_*_original`.

**Específicas de 2023-24**
- **Qué se incluyó**: los 248 archivos del zip. Todos son competiciones de esa temporada en Brasil,
  torneos internacionales de clubes o amistosos.
- **Campeonato Catarinense** (3 partidos) y **Paulista** (30) aparecen como competiciones separadas.
  En el Paulista juegan equipos que no están en la Superliga (Santo André, Atibaia, Vôlei Futuro).
- **Itambé Minas = Minas Tênis Clube**; "Juiz de Fora Vôlei" = JF Vôlei; "Peerlees (PER)" = Peerless.
- **Amistoso Sada–Shabab Al-Ahli**: la cabecera decía 03/12/2023; se usó la fecha del nombre de archivo (03/11/2023).
- **Mineiro: dos archivos con problemas**. `mg23 020 jfv 1x1 moc` está incompleto (se corta en el 3er set)
  y `mg23 001 jfv 3x2 mtc` tiene un punto de diferencia en el 3er set.
- **Acciones sin jugador identificado** (66): sobre todo en el amistoso Suzano–Renata (AM3, 29) y en
  Ciudad–Peerless del Sudamericano (33).
- **24 jugadores para revisar**: en su mayoría jugadores que cambian de equipo entre el Paulista o el
  Mineiro y la Superliga, o cambios de número de camiseta.
- Casi no hay coordenadas.



## Unificación de jugadores

El mismo jugador aparece escrito de varias formas según el scouter (`HILLING MATHEW` /
`Hilling Matthew Alexander`, `WLODARSKI` / `Wlqdarski`, `Brandon Michael` sin apellido…).
`jugador_uid` agrupa esas variantes, siempre dentro del mismo equipo, con estas reglas:

1. **Mismo número de camiseta**: se unen si todas las palabras del nombre más corto aparecen
   en el otro (se aceptan errores de tipeo), con el apellido coincidente o al menos 2 palabras.
2. **Distinto número**: se unen solo si coinciden el apellido y todas las palabras del nombre
   más corto (al menos 2). Estos casos quedan con `revisar = True`.
3. **Entre equipos** (traspasos, o jugadores de la selección chilena que después jugaron
   en Ciudad): se unen solo con nombre idéntico. También quedan con `revisar = True`.
4. Nunca se unen dos registros que aparecen en el mismo partido.

`jugadores_unificados.csv` muestra, para cada `jugador_uid`, el nombre canónico, los
equipos, los números, todas las variantes encontradas y el motivo de la unión. **Conviene
revisar a mano las filas con `revisar = True`**: son 24. Si
alguna unión está mal, avísenme y se ajusta la regla o se agrega una excepción.

El `jugador_uid` es el nombre canónico en formato texto (`RATTRAY_BRANDON_MICHAEL`).
Si dos jugadores distintos quedan con el mismo nombre, se le agrega el equipo al uid.
Entre temporadas el uid **suele** coincidir, pero no está garantizado: el nombre canónico
depende de cómo lo escribió cada scouter.

## Diccionario de `acciones.csv.gz`

| Columna | Descripción |
|---|---|
| `match_id`, `accion_id` | Identificador del partido (estable, derivado del nombre de archivo) y de la fila |
| `fecha`, `tipo_competicion`, `es_principal` | Copiados de `partidos.csv` para filtrar sin hacer merge |
| `set`, `rally_n` | Set y número de rally dentro del partido |
| `marcador_local`, `marcador_visitante` | Marcador **antes** del rally |
| `marcador_*_despues`, `punto_ganado_por` | Marcador después del rally y quién lo ganó (`local`/`visitante`) |
| `gana_rally_equipo_accion` | True si el equipo que hizo la acción ganó ese rally |
| `equipo`, `equipo_nombre`, `rival_nombre` | `local`/`visitante` y nombres normalizados |
| `jugador_numero`, `jugador_nombre` | Camiseta y nombre tal como figura en ese archivo |
| `jugador_uid`, `jugador_canonico` | Identificador unificado y nombre canónico del jugador |
| `jugador_rol` | Armador, Punta, Opuesto, Central, Líbero |
| `fundamento_cod` / `fundamento` | S Saque, R Recepción, A Ataque, B Bloqueo, D Defensa, E Armado, F Free ball, & Código verde |
| `tipo_cod` / `tipo` | Saque/recepción: H flotado, M salto flotado, Q salto potente, T topspin. Resto (tempo): H alta, M media, Q rápida, T tensa, U súper, N slide, O otra |
| `evaluacion_cod` / `evaluacion` | `#` `+` `!` `-` `/` `=` (ver tabla abajo) |
| `combinacion` | Código de combinación de ataque (A) |
| `llamada_armador`, `objetivo_armado` | Llamada del armador (K1, K7…) y destino del armado (F, B, C, P, S) en E |
| `zona_inicio`, `zona_fin`, `subzona_fin` | Zonas 1-9 y subzona A-D |
| `subtipo` / `subtipo_desc` | En ataque: H potente, P colocado, T toque |
| `num_jugadores` | En ataque: número de bloqueadores |
| `especial`, `custom` | Código especial y campo libre del scouter (sin traducir) |
| `equipo_saque`, `fase_juego` | Quién sacó en el rally; `Side-out` si la acción es del equipo receptor, `Break point` si es del que sacó |
| `fase_ataque_raw`, `fase_punto_raw` | Campos originales de DataVolley (r = tras recepción, p = transición; s/p en el punto) |
| `rotacion_local`, `rotacion_visitante` | Zona donde está el armador (1-6) |
| `coord_*`, `inicio_x/y`, `medio_x/y`, `fin_x/y` | Coordenada DataVolley y su posición en la grilla (x 1-100, y 1-101) |
| `local_p1..p6`, `visit_p1..p6` | Número de camiseta en cada zona en ese momento |
| `hora`, `video_seg` | Hora del registro y segundo del video |
| `codigo`, `linea_scout` | Código original y número de línea en el .dvw (para auditar) |

### Evaluaciones (convención estándar de DataVolley)

| | `#` | `+` | `!` | `-` | `/` | `=` |
|---|---|---|---|---|---|---|
| Saque | Ace | Positivo | OK, sin primer tiempo | Negativo | Rival no puede atacar | Error |
| Recepción | Perfecta | Positiva | OK, sin primer tiempo | Negativa | Mala / devuelta | Error |
| Ataque | Punto | Positivo | Bloqueado para reataque | Negativo | Bloqueado (punto rival) | Error |
| Bloqueo | Punto | Positivo | Pobre | Negativo | Invasión | Error |
| Defensa | Perfecta | Positiva | OK | Negativa | Pasa al otro campo | Error |
| Armado | Perfecto | Positivo | OK | Negativo | Malo | Error |

**Código verde (`&`)**: puntos o errores registrados sin un fundamento técnico
(penales, rotación, etc.): `#` = punto para el equipo y `=` = error del equipo.

> Las descripciones siguen la convención estándar. Algunos scouters redefinen
> evaluaciones, así que, ante cualquier duda, se puede revisar el `codigo` original.
