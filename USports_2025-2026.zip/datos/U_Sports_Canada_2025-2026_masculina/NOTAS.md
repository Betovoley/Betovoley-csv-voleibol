# U Sports 2025-26 masculino (vóley universitario de Canadá): notas del dataset

Resumen y problemas específicos de esta temporada. La estructura de las tablas, el diccionario de
columnas y el origen de los datos están en el [README principal](../../README.md).

> **Atención: este dataset no es scout en vivo.** Los 52 archivos fueron generados por el
> **VolleyAI Reconstructor v1.1.0** a partir de la base de datos de VolleyAI (así lo dicen
> `partidos.scouter` y la sección `[3COMMENTS]` de cada archivo). Sirven para practicar y para
> análisis agregados, pero no tienen el mismo valor que un scout hecho por un analista: úsenlos
> sabiendo que cada toque es una reconstrucción.

## Resumen

| | 2025-26 |
|---|---|
| Archivos / partidos distintos | 52 / 51 (1 duplicado) |
| Acciones | 51.706 (52.876 con el duplicado) |
| Competición | `tipo_competicion = "U Sports"` en todos los partidos |
| Fechas | 17/10/2025 → 15/03/2026 |
| Equipos | 17 (Montreal 22 partidos, Brock 19, TMU 10; el resto 6 o menos) |
| Scouter | `VolleyAI Reconstructor v1.1.0` en el 100 % de los archivos |
| Acciones con coordenadas | 0 % |
| Rol de los jugadores | 97,5 % de los registros |
| Jugadores (nombres distintos → unificados) | 233 → 233 |

En todos los archivos, el marcador de cada set reconstruido desde el scout coincide con la
cabecera (`partidos.validacion_marcador = OK`) y todos los partidos están completos.

## Control de calidad

Este dataset se comparó con el scout real del repositorio (Superliga 2024-25 y NCAA 2026). Los
indicadores agregados están en rangos realistas, muy cerca de la NCAA:

| Indicador | U Sports (reconstruido) | NCAA 2026 | Superliga 2024-25 |
|---|---:|---:|---:|
| Side-out | 55,5 % | 56,3 % | 61,5 % |
| Eficiencia de ataque | 0,236 | 0,268 | 0,337 |
| Ace / error de saque | 5,9 % / 18,1 % | 6,3 % / 19,4 % | 4,6 % / 18,5 % |
| Recepción perfecta (#) | 15 % | 13 % | 28 % |
| Acciones por rally | 6,09 | 5,94 | 5,66 |
| Códigos verdes por rally | 0,45 | 0,51 | 0,51 |

También son coherentes: todos los rallies empiezan con un saque y siempre saca el equipo que ganó
el rally anterior.

## Advertencias importantes

- **Reconstrucción, no scout.** Ver el aviso de arriba. Una versión anterior del reconstructor
  (v1.0) se descartó porque los marcadores set a set no coincidían con los resultados; esta
  versión (v1.1.0) sí los reproduce.
- **Horas inventadas.** La columna `hora` es plausible (retrocede solo en el 0,5 % de las acciones), pero no
  es real: la duración mediana de un partido da 68 minutos, contra unos 124 en la Superliga, y entre
  un rally y el siguiente pasan 16 segundos (31 en la Superliga). **No la usen para analizar
  tiempos.** Lo mismo vale para `video_seg`.
- **Cobertura concentrada.** Montreal Carabins y Brock Badgers suman 41 de las 102 apariciones de
  equipos. Sirve sobre todo para analizar esos dos equipos; Toronto y McMaster tienen 1 y 2 partidos.
- **Partido duplicado.** Montreal–UNB del 21/02/2026 vino en dos archivos (12475 y 12514), dos
  reconstrucciones distintas del mismo partido (1.170 y 1.179 acciones). Queda como principal la de
  más acciones (`es_principal`).
- **Jugadores que no están en el plantel.** 1.089 acciones (2,1 %), repartidas en 11 partidos, son
  de números de camiseta que no figuran en el plantel del archivo (sobre todo #15, #7 y #16). Quedan
  sin `jugador_uid` ni nombre.
- **Nombres en distinto orden.** Algunos jugadores aparecen con nombre y apellido invertidos según el
  archivo (por ejemplo, "TOMAS TRUDEL" y "TRUDEL THOMAS", ambos #3 de RMC). La unificación automática
  no los junta: quedan como dos `jugador_uid`.
- **Una fecha corregida.** Montreal–UNB del 21/02/2026 traía en la cabecera el año 2025; se tomó la
  fecha del nombre del archivo (`partidos.fecha_corregida`).
- **Cabeceras desprolijas.** `temporada_original` y `fase_original` vienen vacías o con valores
  inconsistentes ("2024/ 25", "/", "M,Senior", "D1"…). No hay una columna fiable para separar fase
  regular y playoffs.
- **Nombres de equipo.** Venían como "M-MONTREAL CARABINS 2026", "M-TMU BOLD (2025)"…; se quitaron
  el prefijo "M-" y el año, y se normalizaron mayúsculas (Montreal Carabins, TMU Bold).
- **Sin coordenadas**: para el análisis espacial, usen `zona_inicio`/`zona_fin`.

## Jugadores para revisar

En `jugadores_unificados.csv` no hay filas con `revisar = True` en esta temporada (pero ver el punto
sobre nombres invertidos).
