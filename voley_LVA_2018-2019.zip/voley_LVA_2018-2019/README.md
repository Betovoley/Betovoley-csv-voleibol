# Datos de scout de voleibol (DataVolley → CSV)

Archivos DataVolley (`.dvw`) convertidos a CSV para trabajar en Python/pandas.
Temporada 2018-19 de la Liga Argentina de Voleibol masculina.

```
datos/
  Liga_Argentina_de_Voleibol_2018-2019_masculina/
    acciones.csv.gz            una fila por acción de scout (CSV comprimido)
    partidos.csv               una fila por archivo .dvw
    sets.csv                   una fila por set
    jugadores.csv              planteles de cada archivo, con jugador_uid
    jugadores_unificados.csv   un jugador por fila, con sus variantes de nombre
    errores.csv                líneas o archivos que no se pudieron interpretar
scripts/dvw_a_csv.py           el conversor
ejemplos/ejemplo_rapido.py
```

`acciones` va comprimido porque GitHub no acepta archivos de más de 100 MB
(las temporadas grandes superan los 50 MB sin comprimir). pandas lo lee directamente:

```python
import pandas as pd
ruta = "datos/Liga_Argentina_de_Voleibol_2018-2019_masculina/"
acc = pd.read_csv(ruta + "acciones.csv.gz", low_memory=False)

acc = acc[acc["es_principal"]]                       # SIEMPRE: quita partidos duplicados
liga = acc[acc["tipo_competicion"] == "Liga (LVA)"]
```

Las tablas se unen por `match_id`. Para seguir a un jugador entre partidos, usa
`jugador_uid` (está en `acciones` y en `jugadores`) y no el nombre ni el número.

Para convertir un zip nuevo (el nombre del zip con `AAAA-AAAA` se usa para validar fechas):

```bash
pip install -r requirements.txt
python scripts/dvw_a_csv.py Liga_X_2024-2025.zip datos/Liga_X_2024-2025
```

## Resumen

| | 2018-19 |
|---|---|
| Archivos | 178 (1 corrupto, excluido) → 177 leídos |
| Acciones | 179.154 (178.080 con `es_principal`) |
| Liga (LVA) | 115 (fase regular + playoffs hasta la final Bolívar–Obras) |
| Otras competiciones | Amistosos 29, Copa ACLAV 17, Supercopa 4, Copa Desafío 4, Copa Bolívar 3, Copa Challenger 3, Copa Social 1, entrenamiento 1 |
| Equipos de liga | UPCN, Bolívar, Libertad Burgi, Obras de San Juan, UNTREF, Ciudad, River Plate, Gigantes del Sur, Puerto San Martín, Monteros |
| Scouters | ~13 (algunos escritos de varias formas); Betovoley hizo el 31 % de los archivos |
| Acciones con coordenadas | ~0 % |
| Jugadores (nombres distintos → unificados) | 269 → 256 |

El marcador de cada set reconstruido desde el scout coincide con la cabecera en todos los
archivos, salvo en dos (ver abajo).

## Advertencias importantes

**Generales**
- **El dataset no cubre la liga completa** y la cantidad de partidos por equipo es muy
  desigual (UPCN y Ciudad tienen muchos más). Normaliza por partidos o por acciones
  antes de comparar equipos o jugadores.
- **No es solo la liga**: filtra por `tipo_competicion`.
- **Convenciones de scout distintas**: los tipos de ataque y tempo, las combinaciones
  (`X5`, `W4`…) y las llamadas del armador **no son comparables entre scouters**.
  Para comparar con otras temporadas, apóyate en fundamento + evaluación, que es lo más estable.
- Nombres de equipo normalizados en `equipo_local`/`equipo_nombre`; los originales quedan en
  `equipo_*_original`. Obras Sanitarias (Buenos Aires) y Obras de San Juan son clubes distintos.

**Específicas de 2018-19**
- **Archivo corrupto**: `05_Ami00 ARGENTINA U vs BRASIL U21.dvw` son 5.856 bytes en cero, sin
  ningún dato. Se excluyó y figura en `errores.csv`. Si existe otra copia, se puede volver a convertir.
- **1 partido duplicado**: UPCN–Bolívar (LVA 019) está scouteado dos veces, una desde la TV
  (`grupo_duplicado`, `es_principal`).
- **Golden set separado**: el golden set de Ciudad–Puerto (Copa ACLAV, cuartos, partido 2) está
  en un archivo aparte. No es un duplicado: para tener el cruce completo hay que sumar los dos archivos.
- **"Obras Sanitarias SJ" = Obras de San Juan**, igual que en 2019-20.
- "CIUDAD" a secas se normalizó a Ciudad Vóley. "SELECCION JUVENIL ARGENTINA" (amistoso con
  Ciudad, archivo "argentina u21") se normalizó a Argentina Sub-21.
- **Varias copas además de la liga**: Copa Desafío y Copa Challenger (las juegan Monteros, River,
  Gigantes, UNTREF y Ciudad; parecen torneos para equipos eliminados de los playoffs), Copa Bolívar
  (Bolívar, Libertad y SESC RJ; el .dvw la marca como amistoso) y Copa Social. Están todas separadas en `tipo_competicion`.
- **Entrenamiento**: UPCN contra UPCN (2 sets), marcado como `Entrenamiento`; excluirlo.
- **Un punto de diferencia en un set** en 2 archivos: el amistoso UPCN–Caramuru (04) y
  Libertad–UNTREF (LVA 049). Ver `partidos.validacion_marcador`.
- Algunos planteles traían jugadores sin nombre ("UNKNOWN PLAYER 16"): quedan sin `jugador_uid`
  para que no se unan entre equipos.
- **Selecciones juveniles**: varios jugadores de las Sub-19/Sub-21 también juegan en clubes
  (Ciudad, River, Bolívar, UPCN). Esas uniones entre equipos quedan con `revisar = True`.
- Casi no hay coordenadas: para el análisis espacial, usa `zona_inicio`/`zona_fin`.


## Unificación de jugadores

El mismo jugador aparece escrito de varias formas según el scouter (`HILLING MATHEW` /
`Hilling Matthew Alexander`, `WLODARSKI` / `Wlqdarski`, `Brandon Michael` sin apellido…).
`jugador_uid` agrupa esas variantes, siempre dentro del mismo equipo, con estas reglas:

1. **Mismo número de camiseta**: se unen si todas las palabras del nombre más corto aparecen
   en el otro (se aceptan errores de tipeo), con el apellido coincidente o al menos 2 palabras.
2. **Distinto número**: se unen solo si coinciden el apellido y todas las palabras del nombre
   más corto (al menos 2). Estos casos quedan con `revisar = True`.
3. **Entre equipos** (traspasos, o jugadores de la selección chilena que después jugaron
   en Ciudad): se unen solo con nombre idéntico. También quedan con `revisar = True`.
4. Nunca se unen dos registros que aparecen en el mismo partido.

`jugadores_unificados.csv` muestra, para cada `jugador_uid`, el nombre canónico, los
equipos, los números, todas las variantes encontradas y el motivo de la unión. **Conviene
revisar a mano las filas con `revisar = True`**: son 28. Si
alguna unión está mal, avísenme y se ajusta la regla o se agrega una excepción.

El `jugador_uid` es el nombre canónico en formato texto (`RATTRAY_BRANDON_MICHAEL`).
Si dos jugadores distintos quedan con el mismo nombre, se le agrega el equipo al uid.
Entre temporadas el uid **suele** coincidir, pero no está garantizado: el nombre canónico
depende de cómo lo escribió cada scouter.

## Diccionario de `acciones.csv.gz`

| Columna | Descripción |
|---|---|
| `match_id`, `accion_id` | Identificador del partido (estable, derivado del nombre de archivo) y de la fila |
| `fecha`, `tipo_competicion`, `es_principal` | Copiados de `partidos.csv` para filtrar sin hacer merge |
| `set`, `rally_n` | Set y número de rally dentro del partido |
| `marcador_local`, `marcador_visitante` | Marcador **antes** del rally |
| `marcador_*_despues`, `punto_ganado_por` | Marcador después del rally y quién lo ganó (`local`/`visitante`) |
| `gana_rally_equipo_accion` | True si el equipo que hizo la acción ganó ese rally |
| `equipo`, `equipo_nombre`, `rival_nombre` | `local`/`visitante` y nombres normalizados |
| `jugador_numero`, `jugador_nombre` | Camiseta y nombre tal como figura en ese archivo |
| `jugador_uid`, `jugador_canonico` | Identificador unificado y nombre canónico del jugador |
| `jugador_rol` | Armador, Punta, Opuesto, Central, Líbero |
| `fundamento_cod` / `fundamento` | S Saque, R Recepción, A Ataque, B Bloqueo, D Defensa, E Armado, F Free ball, & Código verde |
| `tipo_cod` / `tipo` | Saque/recepción: H flotado, M salto flotado, Q salto potente, T topspin. Resto (tempo): H alta, M media, Q rápida, T tensa, U súper, N slide, O otra |
| `evaluacion_cod` / `evaluacion` | `#` `+` `!` `-` `/` `=` (ver tabla abajo) |
| `combinacion` | Código de combinación de ataque (A) |
| `llamada_armador`, `objetivo_armado` | Llamada del armador (K1, K7…) y destino del armado (F, B, C, P, S) en E |
| `zona_inicio`, `zona_fin`, `subzona_fin` | Zonas 1-9 y subzona A-D |
| `subtipo` / `subtipo_desc` | En ataque: H potente, P colocado, T toque |
| `num_jugadores` | En ataque: número de bloqueadores |
| `especial`, `custom` | Código especial y campo libre del scouter (sin traducir) |
| `equipo_saque`, `fase_juego` | Quién sacó en el rally; `Side-out` si la acción es del equipo receptor, `Break point` si es del que sacó |
| `fase_ataque_raw`, `fase_punto_raw` | Campos originales de DataVolley (r = tras recepción, p = transición; s/p en el punto) |
| `rotacion_local`, `rotacion_visitante` | Zona donde está el armador (1-6) |
| `coord_*`, `inicio_x/y`, `medio_x/y`, `fin_x/y` | Coordenada DataVolley y su posición en la grilla (x 1-100, y 1-101) |
| `local_p1..p6`, `visit_p1..p6` | Número de camiseta en cada zona en ese momento |
| `hora`, `video_seg` | Hora del registro y segundo del video |
| `codigo`, `linea_scout` | Código original y número de línea en el .dvw (para auditar) |

### Evaluaciones (convención estándar de DataVolley)

| | `#` | `+` | `!` | `-` | `/` | `=` |
|---|---|---|---|---|---|---|
| Saque | Ace | Positivo | OK, sin primer tiempo | Negativo | Rival no puede atacar | Error |
| Recepción | Perfecta | Positiva | OK, sin primer tiempo | Negativa | Mala / devuelta | Error |
| Ataque | Punto | Positivo | Bloqueado para reataque | Negativo | Bloqueado (punto rival) | Error |
| Bloqueo | Punto | Positivo | Pobre | Negativo | Invasión | Error |
| Defensa | Perfecta | Positiva | OK | Negativa | Pasa al otro campo | Error |
| Armado | Perfecto | Positivo | OK | Negativo | Malo | Error |

**Código verde (`&`)**: puntos o errores registrados sin un fundamento técnico
(penales, rotación, etc.): `#` = punto para el equipo y `=` = error del equipo.

> Las descripciones siguen la convención estándar. Algunos scouters redefinen
> evaluaciones, así que, ante cualquier duda, se puede revisar el `codigo` original.
