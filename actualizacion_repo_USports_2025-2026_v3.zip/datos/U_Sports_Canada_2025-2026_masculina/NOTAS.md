# U Sports 2025-26 masculino (vóley universitario de Canadá): notas del dataset

Resumen y problemas específicos de esta temporada. La estructura de las tablas, el diccionario de
columnas y el origen de los datos están en el [README principal](../../README.md).

> **Dos fuentes mezcladas.** 190 partidos son **scout real** (VolleyMetrics, 17 de ellos revisados por
> Betovoley, y 2 de Perfbook) y 42 son **reconstrucciones automáticas** del VolleyAI Reconstructor v1.1.0, que no son scout en
> vivo. Para separarlas:
>
> ```python
> p["reconstruido"] = p["scouter"].fillna("").str.contains("Reconstructor")
> ```
>
> Cuando un partido está en las dos fuentes, el scout real queda como principal (`es_principal`).

## Resumen

| | 2025-26 |
|---|---|
| Archivos / partidos distintos | 243 / 232 (11 duplicados, 9 de ellos reconstrucciones de partidos que también están en scout real) |
| Acciones | 235.850 (247.172 con los duplicados) |
| Competición (`tipo_competicion`) | **U Sports** 188 (liga desde el 17/10/2025 y playoffs), **Pretemporada** 38 (13/09 al 11/10/2025) y **Amistoso** 6 (contra colegios de la CCAA y McKendree, de la NCAA) |
| Fechas | 13/09/2025 → 18/03/2026 |
| Equipos | 35; el núcleo es Canada West (Alberta 36 partidos, Manitoba 34, UBC 30, Calgary 30, UBC Okanagan 29, Trinity Western 28…), con 114 partidos de liga entre equipos de esa conferencia |
| Fuera de Canada West | Sobre todo Montreal (27), Brock (19), Laval (16), Windsor (15) y Queen's (12), en buena parte desde las reconstrucciones |
| Acciones con coordenadas | **91 %** en los partidos de VolleyMetrics; 0 % en las reconstrucciones |
| Rol de los jugadores | 31 % de los registros (VolleyMetrics casi no carga roles; las reconstrucciones y los archivos revisados por Betovoley, sí) |
| Jugadores (nombres distintos → unificados) | 926 → 869 |

Indicadores del scout real: side-out 55,7 %, eficiencia de ataque 0,243, 6,10 acciones por rally y
0,50 códigos verdes por rally, muy parecidos a los de la NCAA. En los 239 archivos, el marcador de
cada set reconstruido desde el scout coincide con la cabecera.

17 archivos de VolleyMetrics vienen en una versión revisada por Betovoley (scouter "Betovoley" o
"VolleyMetrics"): algunos tienen roles cargados y la fecha corregida a mano.

## Advertencias importantes

- **Fechas: VolleyMetrics probablemente usa UTC.** En los 8 partidos que están en las dos fuentes, la
  fecha de VolleyMetrics es **un día después** de la del VolleyAI Reconstructor (14/02 frente a 13/02,
  25/01 frente a 24/01…). La hora de las cabeceras de VolleyMetrics es casi siempre de madrugada
  (01.00, 02.00, 12.45), y en varios archivos revisados a mano por Betovoley la fecha se corrigió un día
  hacia atrás. Todo indica que VolleyMetrics guarda la fecha en UTC: un partido a las 19:00 en Canadá
  ya es el día siguiente en UTC. Por eso es probable que **muchas fechas de VolleyMetrics estén un día
  después de la real**, sobre todo en partidos de noche. Hasta confirmarlo, se dejaron como vienen
  (salvo los 17 archivos revisados); no usen la fecha para análisis que dependan del día exacto
  (por ejemplo, el descanso entre partidos).
- **Local y visitante en las reconstrucciones.** En uno de esos 8 partidos (Sherbrooke–Montreal del
  31/01), el reconstructor puso a Montreal como local y el scout real lo pone como visitante.
- **Horas inventadas en las reconstrucciones.** La columna `hora` de los 42 partidos reconstruidos no
  es real: no la usen para analizar tiempos.
- **Fechas en la cabecera de VolleyMetrics.** Las cabeceras vienen vacías (118) o en mes/día, a veces
  con el año mal. Se usó la fecha del nombre del archivo ("&2025-11-09 …"), que es fiable. Está
  anotado en `partidos.fecha_corregida`.
- **Pretemporada.** La liga regular de Canada West empezó el 17/10/2025. Los partidos anteriores
  (torneos de septiembre y octubre, con cruces entre conferencias como UBC–Montreal o Calgary–York) se
  marcaron como `Pretemporada`. Los partidos contra NAIT, Red Deer, Camosun (colegios de la CCAA) y
  McKendree (NCAA) se marcaron como `Amistoso`. Los dos McKendree–Queen's Gaels del 28/02/2026 también
  están en el dataset NCAA 2026, con el mismo `match_id`: si se combinan, hay que quitarlos una vez.
- **Un archivo excluido**: `2025-03-01 609152 WIND-YORK(VM)` es de la temporada 2024-25 (su cabecera
  dice 2024/2025 y ningún jugador de Windsor coincide con el resto). Está en `errores.csv`.
- **Partido duplicado de VolleyMetrics**: UBC Okanagan–MacEwan del 09/11 vino con dos IDs (687221 y
  709202).
- **Un archivo con el nombre equivocado**: `WINDSOR VS TORONTO 2` es Western–Windsor según la cabecera.
- **5 partidos incompletos** de VolleyMetrics (por ejemplo, Alberta–Winnipeg del 01/03, cortado en el
  set 2). Ver `partidos.partido_completo`.
- **Nombres de equipo.** VolleyMetrics usa el nombre de la universidad ("University of Alberta
  (Men's)") y el reconstructor, ciudad + apodo ("M-MONTREAL CARABINS 2026"). Todo se unificó a
  institución + apodo: Alberta Golden Bears, UBC Thunderbirds, Montreal Carabins, Queen's Gaels
  ("Kingston Queens" en el reconstructor)…
- **Problemas propios de las reconstrucciones** (ver el informe sobre el VolleyAI Reconstructor):
  acciones de números que no están en el plantel y nombres con nombre y apellido invertidos
  ("TOMAS TRUDEL" / "TRUDEL THOMAS").

## Jugadores para revisar

En `jugadores_unificados.csv` hay 33 filas con `revisar = True`. Casi todas son jugadores con dos
números en el mismo equipo, varios de UBC Okanagan (Kim Johan aparece con cuatro: 0, 21, 23 y 25).
Hay pases o errores entre equipos: Palanca Aidan (McMaster y UBC Okanagan) y Westermeier-Ly Austin
(MacEwan y Red Deer).
