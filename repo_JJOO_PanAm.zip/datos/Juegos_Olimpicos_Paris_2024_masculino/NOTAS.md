# Juegos Olímpicos de París 2024, vóley masculino: notas del dataset

Resumen y problemas específicos del torneo. La estructura de las tablas, el diccionario de columnas
y el origen de los datos están en el [README principal](../../README.md).

## Resumen

| | París 2024 |
|---|---|
| Archivos / partidos distintos | 26 / 26: **el torneo completo** |
| Acciones | 27.075 |
| Competición | `tipo_competicion = "Juegos Olímpicos"` en todos los partidos; la fase está en `fase_original` ("Pool A/B/C", "Quartas de Final", "Semifinal", "Final Bronce", "Final Oro") |
| Fechas | 26/07/2024 → 10/08/2024 |
| Fase de grupos | 18 partidos, 3 grupos de 4 |
| Fase final | Cuartos (4), semifinales (Francia 3-0 Italia, Polonia 3-2 Estados Unidos), bronce (**Estados Unidos 3-0 Italia**) y la final, que ganó **Francia 3-0 a Polonia** |
| Equipos | Alemania, Argentina, Brasil, Canadá, Egipto, Eslovenia, Estados Unidos, Francia, Italia, Japón, Polonia, Serbia |
| Scouters | Paolo Perrone (6), Felipe Lima (3), Contrario Ivan (3), RK (2), Juan Manuel Mendez (2); 10 archivos sin scouter |
| Acciones con coordenadas | 8 % |
| Rol de los jugadores | 92 % de las acciones |
| Jugadores (nombres distintos → unificados) | 160 → 152 |

Es scout real, hecho por analistas de distintas selecciones. En los 26 partidos, el marcador de cada
set reconstruido desde el scout coincide con la cabecera. Indicadores generales: side-out 60,6 %,
eficiencia de ataque 0,328, 5,98 acciones por rally y 0,45 códigos verdes por rally.

## Advertencias importantes

- **Local y visitante no significan nada**: todos los partidos son en sede neutral. Además, en 3
  archivos el orden de la cabecera es distinto al del nombre del archivo (Japón–Alemania,
  Canadá–Serbia y la semifinal Italia–Francia), porque el analista puso primero a su equipo. Para
  análisis por selección, usen `equipo_nombre` en `acciones` y no el lado local/visitante.
- **Distintos analistas, distintos criterios.** Cada archivo es de un scouter distinto (de Italia,
  Brasil, Argentina, Alemania…), así que las evaluaciones (sobre todo recepción y defensa) no son del
  todo homogéneas entre partidos.
- **Pocas coordenadas** (8 %): para el análisis espacial, usen `zona_inicio`/`zona_fin`.
- **Nombres.** Las selecciones están en español, como en los Mundiales del repo (Polonia, Estados
  Unidos, Alemania…), aunque las cabeceras mezclan inglés, español e italiano.

## Jugadores para revisar

En `jugadores_unificados.csv` hay 1 fila con `revisar = True`: Abdelsalam Abdelmoaty Mostafa (Egipto)
aparece con el 15 y el 16.
