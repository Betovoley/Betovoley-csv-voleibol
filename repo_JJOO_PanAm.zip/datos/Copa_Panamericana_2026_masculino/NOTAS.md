# Copa Panamericana 2026, vóley masculino: notas del dataset

Resumen y problemas específicos del torneo. La estructura de las tablas, el diccionario de columnas
y el origen de los datos están en el [README principal](../../README.md).

## Resumen

| | Copa Panamericana 2026 (Cuernavaca, México) |
|---|---|
| Archivos / partidos distintos | 24 archivos; 1 corrupto y excluido: 23 partidos |
| Acciones | 19.498 |
| Competición | `tipo_competicion = "Copa Panamericana"` en todos los partidos |
| Fechas | 09/08/2026 → 16/08/2026 |
| Grupo A | **Completo** (10 partidos): Canadá Next Gen, Estados Unidos, Puerto Rico, Costa Rica, Trinidad y Tobago |
| Grupo B | 7 de 10 partidos: Cuba, México, República Dominicana, Guatemala, Curazao. Faltan Curazao–Guatemala y República Dominicana–Curazao, y República Dominicana–Guatemala está corrupto |
| Fase final | Cuartos Estados Unidos–República Dominicana y Cuba–Puerto Rico, semifinales (Puerto Rico 3-1 Canadá Next Gen, Estados Unidos 3-0 México), bronce (**Canadá Next Gen 3-1 México**) y la final, que ganó **Estados Unidos 3-1 a Puerto Rico**. No están los partidos por el 5.º al 10.º puesto |
| Scouter | Betovoley en 22 archivos (la final no tiene scouter en la cabecera) |
| Acciones con coordenadas | 0 % |
| Rol de los jugadores | 90 % de las acciones |
| Jugadores (nombres distintos → unificados) | 138 → 132 |

Es scout real y de un solo analista, así que el criterio de evaluación es homogéneo en todo el
torneo. En los 23 partidos, el marcador de cada set reconstruido desde el scout coincide con la
cabecera. Indicadores generales: side-out 59,1 %, eficiencia de ataque 0,285, 5,34 acciones por rally
y 0,55 códigos verdes por rally.

## Advertencias importantes

- **Canadá jugó con su equipo Next Gen**, no con la selección mayor: se dejó como "Canadá Next Gen"
  para no mezclarlo con Canadá en otros datasets (por ejemplo, los JJOO de París 2024).
- **Un archivo excluido** (`errores.csv`): `18 pb dom 2-3 gua` no es un .dvw legible (los bytes
  parecen cifrados o dañados). Si tienen otra copia, se puede agregar.
- **Fase.** `fase_original` dice "Semifinals" en el partido por el bronce y viene vacía en la final.
  Usen el código del nombre del archivo: `pa`/`pb` = grupos, `qf` = cuartos, `sf` = semifinal,
  `fb` = bronce, `fo` = final.
- **La final viene con la cabecera incompleta** (sin temporada, competición, fase ni scouter) y con
  Puerto Rico como "local"; el marcador sí cierra (Estados Unidos 3-1).
- **Local y visitante no significan nada** (sede única), salvo para México, que jugaba en casa.
- **Fechas.** Tres cabeceras venían en mes/día (08/09, 08/10, 08/12); se corrigieron al 9, 10 y 12 de
  agosto (`partidos.fecha_corregida`).
- **Sin coordenadas**: para el análisis espacial, usen `zona_inicio`/`zona_fin`.
- Los nombres "Puerto Rico 2026" y "GUATEMALA 2026" se unificaron como Puerto Rico y Guatemala.

## Jugadores para revisar

En `jugadores_unificados.csv` no hay filas con `revisar = True`.
