# Rusia 2024-25 masculino (Superliga, Copa de Rusia, Copa de Leyendas y Supercopa): notas del dataset

Resumen y problemas específicos de este dataset. La estructura de las tablas, el diccionario de
columnas y el origen de los datos están en el [README principal](../../README.md).

> **Temporada vista desde los dos Zenit.** Son 98 partidos, casi todos de Zenit Kazán (54) y Zenit
> San Petersburgo (52). Sirven muy bien para analizar esos dos equipos y sus rivales directos, pero
> no son la Superliga completa: no comparen la tabla de todos los equipos con esto.

## Resumen

| | 2024-25 |
|---|---|
| Archivos / partidos distintos | 98 / 98 (sin duplicados) |
| Acciones | 89.795 |
| Competiciones (`tipo_competicion`) | **Superliga Rusa** 69 (54 de fase regular y 15 de playoffs, con la final completa: Zenit Kazán 3-0 a Zenit San Petersburgo), **Copa de Rusia** 14, **Copa de Leyendas** 14 (pretemporada) y **Supercopa de Rusia** 1 |
| Fechas | 23/08/2024 → 11/05/2025 |
| Equipos | 16 |
| Scouters | Sosnin Dmitry (57, Zenit Kazán), Dmitriy Feschenko (22, Zenit San Petersburgo), Dmitriy Alpeev (14) y otros |
| Acciones con coordenadas | 0 % (sí hay zonas en el 58 % de las acciones) |
| Rol de los jugadores | 100 % de los registros |
| Jugadores (nombres distintos → unificados) | 343 → 284 |

Es scout real. Los nombres de jugadores ya vienen transliterados al alfabeto latino. En los 98
partidos, el marcador de cada set reconstruido desde el scout coincide con la cabecera. Indicadores
generales: side-out 59,6 %, eficiencia de ataque 0,325, 5,66 acciones por rally y 0,39 códigos
verdes por rally.

## Advertencias importantes

- **Local y visitante invertidos en 13 partidos**: 11 de Zenit San Petersburgo (su analista pone a
  su equipo como local también de visitante), 1 de Dinamo Moscú y 1 de Enisey. El local real está en
  el nombre del archivo (el primer código es el local):

  ```python
  cod_equipo = {"kaz": "Zenit Kazan", "spb": "Zenit Saint-Petersburg", "lon": "Lokomotiv Novosibirsk",
                "bel": "Belogorie Belgorod", "dyn": "Dynamo Moscow", "kuz": "Kuzbass Kemerovo",
                "dlo": "Dynamo Leningradskaya Oblast", "eni": "Enisey Krasnoyarsk",
                "fak": "Fakel Novy Urengoy", "nov": "Nova Novokuybyshevsk", "ask": "ASK Nizhny Novgorod",
                "nef": "Neftyanik Orenburg", "mgt": "MGTU Moscow", "ufa": "Dynamo-Ural Ufa",
                "zsk": "Gazprom-Ugra Surgut"}
  cod = p["archivo"].str.extract(r"\s([a-z]{3})-([a-z]{3})")
  invertido = (cod[0].map(cod_equipo) == p["equipo_visitante"]) & (cod[1].map(cod_equipo) == p["equipo_local"])
  p["local_real"] = p["equipo_local"].where(~invertido, p["equipo_visitante"])
  ```

- **Fechas.** 17 cabeceras no traen fecha y una trae 30/12/1899 (la fecha "cero" de Excel). En esos
  casos se tomó la fecha del nombre del archivo, que empieza con aa-mm-dd ("&25-01-26 …" =
  26/01/2025). Ver `partidos.fecha_corregida`.
- **Cabeceras en ruso.** 10 archivos tienen la competición y la fase en cirílico (codificación cp1251);
  el conversor lo detecta y las guarda bien escritas en `competicion_original`/`fase_original`
  ("Мужчины - Кубок России 2025, Финал Шести").
- **Fase de los playoffs de la Superliga**: está en el nombre del archivo, no en la cabecera:
  `qpoff` (repechaje), `po14` (cuartos), `sf` (semis), `fin` (final).
- **Nombres de equipo.** Se unificaron variantes como "Zenit SPB", "Zenit SaintPetersburg",
  "Lokomotiv (Novosibirsk)", "Fakel Yamal Noviy Urengoy" u "Orenburzhie Orenburg" (= Neftyanik, con el
  mismo código `nef` en los archivos). Son los mismos nombres que en el dataset de Rusia 2025-26, así
  que se pueden combinar.
- Sin coordenadas: para el análisis espacial, usen `zona_inicio`/`zona_fin`.

## Jugadores para revisar

En `jugadores_unificados.csv` hay 8 filas con `revisar = True`. Todas son jugadores en dos equipos
(por ejemplo, Kostadinov Slavi en Dynamo-Ural Ufa y Zenit San Petersburgo, o Bogatko Maxim en
Lokomotiv y Zenit San Petersburgo). Pueden ser pases durante la temporada, sobre todo los que
pasan por MGTU Moscú, pero conviene verificarlos.
