# U Sports 2025-26 masculino (vóley universitario de Canadá): notas del dataset

Resumen y problemas específicos de esta temporada. La estructura de las tablas, el diccionario de
columnas y el origen de los datos están en el [README principal](../../README.md).

> **Dos fuentes mezcladas.** 186 partidos son **scout real** (184 de VolleyMetrics y 2 de Perfbook) y
> 42 son **reconstrucciones automáticas** del VolleyAI Reconstructor v1.1.0, que no son scout en
> vivo. Para separarlas:
>
> ```python
> p["reconstruido"] = p["scouter"].fillna("").str.contains("Reconstructor")
> ```
>
> Cuando un partido está en las dos fuentes, el scout real queda como principal (`es_principal`).

## Resumen

| | 2025-26 |
|---|---|
| Archivos / partidos distintos | 239 / 228 (11 duplicados, 9 de ellos reconstrucciones de partidos que también están en scout real) |
| Acciones | 230.846 (242.168 con los duplicados) |
| Competición (`tipo_competicion`) | **U Sports** 184 (liga desde el 17/10/2025 y playoffs), **Pretemporada** 38 (13/09 al 11/10/2025) y **Amistoso** 6 (contra colegios de la CCAA y McKendree, de la NCAA) |
| Fechas | 13/09/2025 → 18/03/2026 |
| Equipos | 35; el núcleo es Canada West (Alberta 36 partidos, Manitoba 32, UBC 30, Calgary 30, Trinity Western 28, UBC Okanagan 27…), con 110 partidos de liga entre equipos de esa conferencia |
| Fuera de Canada West | Sobre todo Montreal (27), Brock (19), Laval (16), Windsor (15) y Queen's (12), en buena parte desde las reconstrucciones |
| Acciones con coordenadas | **91 %** en los partidos de VolleyMetrics; 0 % en las reconstrucciones |
| Rol de los jugadores | 30 % de los registros (VolleyMetrics casi no carga roles; las reconstrucciones, sí) |
| Jugadores (nombres distintos → unificados) | 916 → 864 |

Indicadores del scout real: side-out 55,7 %, eficiencia de ataque 0,242, 6,10 acciones por rally y
0,50 códigos verdes por rally, muy parecidos a los de la NCAA. En los 239 archivos, el marcador de
cada set reconstruido desde el scout coincide con la cabecera.

## Advertencias importantes

- **Fechas de las reconstrucciones, un día antes.** En los 8 partidos que están en las dos fuentes, la
  fecha del VolleyAI Reconstructor es **el día anterior** a la de VolleyMetrics (13/02 frente a 14/02,
  24/01 frente a 25/01…). Parece un error de zona horaria del reconstructor. En esos 8 se usó la fecha
  real, pero las **42 reconstrucciones sin versión real probablemente también están un día antes**.
  No se corrigieron porque no hay forma de confirmarlo partido por partido.
- **Local y visitante en las reconstrucciones.** En uno de esos 8 partidos (Sherbrooke–Montreal del
  31/01), el reconstructor puso a Montreal como local y el scout real lo pone como visitante.
- **Horas inventadas en las reconstrucciones.** La columna `hora` de los 42 partidos reconstruidos no
  es real: no la usen para analizar tiempos.
- **Fechas en la cabecera de VolleyMetrics.** Las cabeceras vienen vacías (118) o en mes/día, a veces
  con el año mal. Se usó la fecha del nombre del archivo ("&2025-11-09 …"), que es fiable. Está
  anotado en `partidos.fecha_corregida`.
- **Pretemporada.** La liga regular de Canada West empezó el 17/10/2025. Los partidos anteriores
  (torneos de septiembre y octubre, con cruces entre conferencias como UBC–Montreal o Calgary–York) se
  marcaron como `Pretemporada`. Los partidos contra NAIT, Red Deer, Camosun (colegios de la CCAA) y
  McKendree (NCAA) se marcaron como `Amistoso`. Los dos McKendree–Queen's Gaels del 28/02/2026 también
  están en el dataset NCAA 2026, con el mismo `match_id`: si se combinan, hay que quitarlos una vez.
- **Un archivo excluido**: `2025-03-01 609152 WIND-YORK(VM)` es de la temporada 2024-25 (su cabecera
  dice 2024/2025 y ningún jugador de Windsor coincide con el resto). Está en `errores.csv`.
- **Partido duplicado de VolleyMetrics**: UBC Okanagan–MacEwan del 09/11 vino con dos IDs (687221 y
  709202).
- **Un archivo con el nombre equivocado**: `WINDSOR VS TORONTO 2` es Western–Windsor según la cabecera.
- **5 partidos incompletos** de VolleyMetrics (por ejemplo, Alberta–Winnipeg del 01/03, cortado en el
  set 2). Ver `partidos.partido_completo`.
- **Nombres de equipo.** VolleyMetrics usa el nombre de la universidad ("University of Alberta
  (Men's)") y el reconstructor, ciudad + apodo ("M-MONTREAL CARABINS 2026"). Todo se unificó a
  institución + apodo: Alberta Golden Bears, UBC Thunderbirds, Montreal Carabins, Queen's Gaels
  ("Kingston Queens" en el reconstructor)…
- **Problemas propios de las reconstrucciones** (ver el informe sobre el VolleyAI Reconstructor):
  acciones de números que no están en el plantel y nombres con nombre y apellido invertidos
  ("TOMAS TRUDEL" / "TRUDEL THOMAS").

## Jugadores para revisar

En `jugadores_unificados.csv` hay 28 filas con `revisar = True`. Casi todas son jugadores con dos
números en el mismo equipo, varios de UBC Okanagan (Kim Johan aparece con cuatro: 0, 21, 23 y 25).
Hay pases o errores entre equipos: Palanca Aidan (McMaster y UBC Okanagan) y Westermeier-Ly Austin
(MacEwan y Red Deer).
