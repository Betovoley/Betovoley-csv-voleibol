# NCAA 2026 masculina (vóley universitario de EE. UU.): notas del dataset

Resumen y problemas específicos de esta temporada. La estructura de las tablas, el diccionario
de columnas y el origen de los datos están en el [README principal](../../README.md).

## Resumen

| | 2026 |
|---|---|
| Archivos / partidos distintos | 296 / 295 |
| Acciones | 276.133 (275.412 con `es_principal`) |
| Competición | `tipo_competicion = "NCAA"` en todos los partidos |
| Fechas | 03/01/2026 → 05/04/2026 |
| Equipos | 66 (de 1 a 27 partidos por equipo) |
| Scouters | 1: VolleyMetrics hizo el 100 % de los archivos |
| Acciones con coordenadas | ≈ 91 % |
| Jugadores (nombres distintos → unificados) | 1.423 → 1.424 `jugador_uid` (hay homónimos en equipos distintos) |

En todos los archivos, el marcador de cada set reconstruido desde el scout coincide con la
cabecera (`partidos.validacion_marcador = OK`).

## Advertencias importantes

- **Cubre la temporada regular hasta el 5 de abril**: no están los torneos de conferencia ni el
  campeonato NCAA. Tampoco hay una columna que separe la fase: todos los partidos figuran como `NCAA`.
- **Cobertura muy despareja por equipo**: Lewis, BYU, Hawaii, Penn State, Ohio State, Pepperdine o
  Loyola tienen más de 20 partidos, y muchos rivales aparecen una sola vez. Para comparar equipos,
  conviene quedarse con los que tienen bastantes partidos y normalizar.
- **Divisiones mezcladas**: hay equipos de distintas divisiones de la NCAA y algunos de la NAIA
  (Vanguard, Jessup, Menlo, The Master's, entre otros), sin una columna que los distinga.
- **Un solo scouter (VolleyMetrics)**: los códigos son homogéneos dentro de la temporada, pero siguen
  las convenciones de VolleyMetrics. Por ejemplo, el tempo `T` es el más usado y las combinaciones son
  `X5`, `V5`, `X6`, `X1`… Para comparar con Argentina o Brasil, usa fundamento + evaluación.
- **Coordenadas**: ≈ 91 % de las acciones las tienen. Es el mejor dataset del repo para análisis espacial.
- **Rol de los jugadores**: VolleyMetrics solo marca los líberos. Hay roles completos para Long Beach y
  McKendree (en total, rol en el 14 % de los registros). Se van a completar los demás equipos cuando
  lleguen los archivos con roles cargados.
- **Fechas**: en 279 archivos la cabecera venía vacía o en formato de EE. UU. (mes/día/año). Se usó la
  fecha del nombre de archivo, que es la correcta. Queda registrado en `partidos.fecha_corregida`.
- **1 partido duplicado**: Emmanuel College–NYU del 08/03/2026 está dos veces, con dos IDs de
  VolleyMetrics distintos (`grupo_duplicado`/`es_principal`).
- **Amistosos contra U Sports**: los dos McKendree–Queen's Gaels del 28/02/2026 son amistosos contra una
  universidad canadiense (`tipo_competicion = "Amistoso"`). Están también en el dataset de U Sports
  2025-26, con el mismo `match_id`: si se combinan los dos datasets, hay que quitarlos una vez.
- **4 archivos con un set sin terminar** (`partido_completo = False`). Al scout le faltan los
  últimos puntos de ese set: BYU–UC Irvine (5º set, 8-12), Lewis–UC San Diego (4º set, 24-25),
  Northern Kentucky–Lindenwood (2º set, 18-24) y UC Merced–BYU (1er set, 19-24).
- **Jugadores sin nombre real**: VolleyMetrics usa nombres de relleno ("SHIRT BLOOD" para la camiseta
  de repuesto por sangre, "18 PLAYER", "23 PLAYER"…). Esos registros quedan sin `jugador_uid` (≈ 290
  acciones), para que no se mezclen jugadores de equipos distintos.
- **Nombres de equipo**: se quitó el sufijo "(Men's)" / "Men's Volleyball" y se unificaron las variantes
  ("Emmanuel College (MA)" → Emmanuel College). Se mantienen los nombres oficiales completos de las
  universidades; en los nombres de archivo aparecen abreviados (PSU, UH, UCI, BYU…).

## Jugadores para revisar

En `jugadores_unificados.csv` hay 24 filas con `revisar = True`: conviene verificarlas a mano. Casi
todas son jugadores con dos números de camiseta distintos en el mismo equipo.
