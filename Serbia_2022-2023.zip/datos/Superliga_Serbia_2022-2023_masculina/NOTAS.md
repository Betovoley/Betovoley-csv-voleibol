# Superliga de Serbia masculina 2022-23: notas del dataset

Resumen y problemas específicos de esta temporada. La estructura de las tablas, el diccionario de
columnas y el origen de los datos están en el [README principal](../../README.md).

> **Primera parte de la temporada.** Los archivos van del 07/10/2022 al 10/02/2023: la ida completa
> casi entera y las primeras 5 fechas de la vuelta. Faltan las últimas 6 fechas de la vuelta, los
> playoffs y la final de la Copa (Partizan 3-2 Vojvodina, 26/02/2023).

## Resumen

| | 2022-23 |
|---|---|
| Archivos / partidos distintos | 106 / 106 (sin duplicados) |
| Acciones | 100.580 |
| Competiciones (`tipo_competicion`) | **Superliga Serbia** 90, **Copa de Serbia** 15 y **Supercopa de Serbia** 1 (Vojvodina 1-3 Partizan, 11/10/2022) |
| Fechas | 07/10/2022 → 10/02/2023 |
| Liga regular | 90 de los 96 partidos jugados hasta el 10/02 (12 equipos, ida y vuelta): **ida 63 de 66**, vuelta 27 de 30 (fechas 12 a 16) |
| Copa de Serbia | Octavos (7 de 8, 07-08/10), cuartos completos (01-02/11) y las dos semifinales de ida y vuelta (Radnički–Partizan y Mladi Radnik–Vojvodina, 22-23/11 y 27-28/12) |
| Equipos | Crvena Zvezda Beograd, Jedinstvo Stara Pazova, Karadjordje Topola, Mladi Radnik Pozarevac, Novi Sad Maneks, Partizan Efbet, Radnicki Kragujevac, Ribnica Kraljevo, Spartak Ljig, Spartak Subotica, Takovo Gornji Milanovac, Vojvodina Novi Sad; en la Copa, también Gracac, Mladenovac y Nis |
| Scouter | VolleyMetrics en todos los archivos |
| Acciones con coordenadas | **91 %** |
| Rol de los jugadores | 8 % de las acciones (VolleyMetrics casi no carga roles) |
| Jugadores | 313 nombres distintos, 343 registros en `jugadores_unificados.csv` (ver abajo) |

Es scout real. En los 106 archivos, el marcador de cada set reconstruido desde el scout coincide con
la cabecera. Indicadores generales: side-out 57,9 %, eficiencia de ataque 0,293, 5,73 acciones por
rally y 0,47 códigos verdes por rally. Local y visitante de la cabecera son correctos: todos los
cruces de liga con ida y vuelta cambian de cancha.

## Advertencias importantes

- **Competición.** Las cabeceras de VolleyMetrics no traen competición ni fase (la temporada dice
  "2015/2016"). La Copa y la Supercopa se marcaron a mano por fecha y por el cuadro de la Copa
  (`scripts/dvw_a_csv.py`, `OVERRIDES_EQUIPO`). La ida de la liga va del 14/10 al 16/12 y la vuelta
  empieza el 23/12.
- **Un partido con el rival equivocado.** `2023-02-03 359004 PAR-SPAR` dice Partizan–Spartak Ljig,
  pero los que juegan son los de **Spartak Subotica** (Vulikic, Omar, Jungic, Khan…). Se corrigió el
  rival a Spartak Subotica: es el Partizan–Subotica de la ida, que faltaba. **La fecha es dudosa**,
  porque Subotica jugó contra Ribnica el mismo 03/02. El Partizan–Ljig de la vuelta es el archivo del
  05/02 (`370544`).
- **Planteles de Spartak Ljig mezclados con los de Spartak Subotica.** En los archivos de Ljig desde
  el 27/01 (contra Novi Sad, Partizan y Karadjordje), VolleyMetrics cargó a los jugadores de los dos
  Spartak juntos. En el del 27/01, el #7 aparece como Vulikic (de Subotica) en vez de Mirkovic, así
  que 80 acciones de Mirkovic quedaron a nombre de Vulikic. Las estadísticas por jugador de Spartak
  Ljig en esos partidos no son confiables.
- **Planteles de la Copa.** Los rivales de divisiones inferiores (Gracac, Mladenovac, Nis) traen
  planteles con jugadores de otros equipos de la Superliga. Por eso aparecen jugadores "en dos
  equipos" que no son pases reales.
- **4 partidos incompletos** (`partido_completo = False`): Novi Sad–Ribnica del 19/11,
  Radnički–Partizan del 22/11 (ida de la semifinal de Copa), Subotica–Karadjordje del 09/12 y
  Crvena Zvezda–Mladi Radnik del 13/12. El scout está cortado.
- **Hora.** `hora` dice 02:00–06:00 en casi todos los archivos: es la hora de carga de
  VolleyMetrics, no la del partido. Las acciones no tienen hora.
- **Fechas.** Las cabeceras vienen vacías o en mes/día; se usó la fecha del nombre del archivo, que
  coincide con los viernes de cada jornada.

## Jugadores para revisar

En `jugadores_unificados.csv` hay 41 filas con `revisar = True`, casi todas por los planteles
mezclados de VolleyMetrics:

- Los 13 jugadores de Spartak Subotica que aparecen también en Spartak Ljig (ver arriba).
- Jugadores "de Nis" que en realidad son de Partizan, Spartak Ljig o Spartak Subotica.
- Números distintos para un mismo jugador en Vojvodina (Cubrilo Nemanja con el 11 y el 67, Kopitic
  con el 14 y el 44…), en Karadjordje y en Spartak Ljig.

Además, 30 nombres quedaron como dos `jugador_uid` porque aparecen en planteles de dos equipos y el
unificador no los juntó (por ejemplo, Ilic Danilo en Crvena Zvezda y Spartak Ljig). Si analizan
jugadores, verifiquen en qué equipo tienen acciones.
