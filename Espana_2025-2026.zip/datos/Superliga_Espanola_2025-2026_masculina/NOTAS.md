# Superliga española masculina 2025-26: notas del dataset

Resumen y problemas específicos de esta temporada. La estructura de las tablas, el diccionario de
columnas y el origen de los datos están en el [README principal](../../README.md).

## Resumen

| | 2025-26 |
|---|---|
| Archivos / partidos distintos | 128 / 126 (2 copias duplicadas) |
| Acciones | 131.612 (133.238 con las copias) |
| Competiciones (`tipo_competicion`) | **Superliga Española** 124 (121 de liga regular y 3 de playoffs) y **Copa del Rey** 2 |
| Fechas | 25/10/2025 → 19/04/2026 |
| Liga regular | 121 de 132 partidos: jornadas 1 a 20 completas, 1 partido de la jornada 21 y ninguno de la 22 |
| Playoffs | Solo los cuartos de final CV Guaguas–Unicaja (3 partidos, ganó Guaguas 2-1) |
| Copa del Rey | Cuartos y semifinal de Cisneros La Laguna (ganó a Soria y perdió con Melilla) |
| Equipos | 12: Bus Leader San Roque, Cisneros La Laguna, Conectabalear CV Manacor, Conqueridor Valencia, CV Guaguas, CV Melilla, Grupo Herce Soria, Instercap Asisa Tarragona, Pamesa Teruel, Servigroup Playas de Benidorm, UC3M Voleibol Leganés, Unicaja Costa de Almería |
| Scouters | Cada club scoutea sus partidos (unos 15 analistas); 14 archivos sin nombre |
| Acciones con coordenadas | **59 %** (93 partidos con coordenadas en la mayoría de las acciones): es de los pocos datasets del repo que permiten análisis espacial fino |
| Rol de los jugadores | 99,9 % de los registros |
| Jugadores (nombres distintos → unificados) | 204 → 196 |

Es scout real; cada archivo lo hizo el analista de uno de los clubes. En los 128 archivos, el
marcador de cada set reconstruido desde el scout coincide con la cabecera. Indicadores generales:
side-out 61,4 %, eficiencia de ataque 0,304, 6,06 acciones por rally y 0,48 códigos verdes por rally.

## Advertencias importantes

- **Local y visitante invertidos en unos 16 partidos.** Algunos analistas ponen a su equipo
  siempre como local ("*") en la cabecera y primero en el nombre del archivo, también cuando juega de
  visitante: sobre todo Cisneros La Laguna (que figura como local en sus 20 partidos) y, en menor
  medida, Valencia y San Roque. Con el campo Home/Away de la cabecera y los partidos de ida y vuelta
  se identificaron 14 archivos invertidos:

  ```python
  invertidos = [
      "&251025.SM1.J1.Cisneros La vs CV Guaguas.0-3.dvw",
      "&251101.SM1.J2.Cisneros La vs Conectabale.dvw",
      "&251101.SM1.J2.Valencia-San Roque.3-0.dvw",
      "&251217.SM1.J10.Cisneros-Benidorm.dvw",
      "&260111.SM1.J12.Cisneros-Melilla.1-3dvw",
      "&260207.SM1.J16.Cisneros-Valencia.dvw",
      "&260214.SM1.J17.Cisneros-Unicaja.3-1.dvw",
      "&260214.SM1.J17.Melilla-Valencia.3-1.dvw",
      "&260214.SM1.J17.Guaguas-Teruel.3-1.dvw",
      "&260221.SM1.J18.Cisneros-Tarragona.3-1.dvw",
      "&260221.SM1.J18.Valencia-Benidorm.2-3.dvw",
      "&260307.SM1.J19.Valencia-Guaguas.3-0.dvw",
      "&260308.SM1.J19.Cisneros-Soria.0-3.dvw",
      "&260314.SM1.J20.Cisneros-Leganes.3-0.dvw",
  ]
  inv = p["archivo"].isin(invertidos)
  p["local_real"] = p["equipo_local"].where(~inv, p["equipo_visitante"])
  p["visitante_real"] = p["equipo_visitante"].where(~inv, p["equipo_local"])
  ```

  Quedan 2 dudas: San Roque–Tarragona (J4 y J17) y San Roque–Teruel (J8 y J20) aparecen las dos veces
  con San Roque de local; uno de cada par se jugó fuera, pero los archivos no permiten saber cuál.
  Ojo: el campo "Home/Away" de `fase_original` es relativo al equipo del analista que scouteó, no al
  local de la cabecera.
- **Copias duplicadas (2)**: Valencia–Guaguas de la J19 viene también en una versión de VolleyMetrics
  (`2026-03-07 745361 CVG-LV(VM)`), y el tercer partido de cuartos Guaguas–Unicaja viene dos veces
  (`260419 4TOS 3` y `POSVM03_4th01`). Quedan marcadas con `es_principal = False`.
- **Un archivo sin el punto de la extensión** (`…Cisneros-Melilla.1-3dvw`); el conversor lo lee igual.
- **Cabecera de otra temporada**: Guaguas–Teruel de la J17 dice "Superliga Masculina 2024-25" en
  `competicion_original`, pero es de 2025-26 (14/02/2026).
- **Nombres de equipo.** Se unificaron "Unicaja Costa de Almeria"/"Almería", "Conectabalear
  Manacor"/"CV Manacor", "Grupo Herce Soria"/"Soria Voleibol" y "Club Voleibol Melilla"/"CV Melilla".
- **Fase.** Para los playoffs y la Copa usen `tipo_competicion` y el nombre del archivo (`4TOS`,
  `CDR`): `fase_original` mezcla "Home - Liga Regular", "Fase regular", "4th - Playoffs SVM", etc.

## Jugadores para revisar

En `jugadores_unificados.csv` hay 3 filas con `revisar = True`: Quesada Justo (Valencia) con cuatro
números distintos (23, 28, 32 y 90), y Rejón Faúndez Gerard y Segura Pérez Carlos (Tarragona), que
tienen el 8 y el 19 cruzados según el archivo.
