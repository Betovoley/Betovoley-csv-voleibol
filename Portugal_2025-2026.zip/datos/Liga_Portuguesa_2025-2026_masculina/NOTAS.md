# Liga portuguesa masculina 2025-26 (Liga UNA Seguros, 1.ª fase): notas del dataset

Resumen y problemas específicos de esta temporada. La estructura de las tablas, el diccionario de
columnas y el origen de los datos están en el [README principal](../../README.md).

## Resumen

| | 2025-26 |
|---|---|
| Archivos / partidos distintos | 129 / 128 (1 copia duplicada) |
| Acciones | 117.727 (119.014 con la copia) |
| Competición | `tipo_competicion = "Liga Portuguesa"`: 1.ª fase de la Liga UNA Seguros (12 equipos, ida y vuelta, 22 jornadas) |
| Fechas | 24/10/2025 → 07/03/2026 |
| Cobertura | 128 de los 132 partidos de la 1.ª fase (ver abajo cuáles faltan) |
| Equipos | AA Espinho, AAS Mamede, Ala N'Alvares Gondomar, CA Madalena, Castelo Maia GC, Clube Kairós, GC Santo Tirso, Leixões SC, SC Espinho, SL Benfica, Sporting CP, Vitória SC |
| Scouters | Unos 17 distintos, algunos escritos de dos formas ("Leonel Rosa"/"leonel rosa"): cada club scoutea sus partidos |
| Acciones con coordenadas | < 1 % (sí hay zonas en el 58 % de las acciones) |
| Rol de los jugadores | 99,8 % de los registros |
| Jugadores (nombres distintos → unificados) | 211 → 208 |

Es scout real; cada archivo lo hizo el analista de uno de los dos clubes (o la federación). En los
129 archivos, el marcador de cada set reconstruido desde el scout coincide con la cabecera.
Indicadores generales: side-out 60,3 %, eficiencia de ataque 0,308, 5,67 acciones por rally y 0,51
códigos verdes por rally.

## Advertencias importantes

- **Fechas.** Es el dataset más desordenado en este punto: cabeceras en día/mes y en mes/día
  mezcladas, y nombres de archivo con la fecha en cuatro formatos ("06.02", "2025.11.08",
  "UNA_J9_06122025", "J3_…" sin fecha). El conversor:
  - toma la fecha del nombre cuando la trae, salvo que deje a un equipo con dos partidos el mismo
    día (le pasó al archivo `2025.11.08_1F_J6_VSCxCAM`, que es del 22/11, como dice su cabecera);
  - corrige el año cuando el nombre lo trae mal (`UNAJ22_07032025` → 07/03/2026);
  - resuelve las fechas ambiguas eligiendo la lectura que cae en el mismo fin de semana que el resto
    de la jornada (por ejemplo, 11/08 → 8 de noviembre).

  Las 16 fechas corregidas están explicadas en `partidos.fecha_corregida`. Ningún equipo queda con
  dos partidos el mismo día. Atención: muchas jornadas son dobles (sábado y domingo seguidos), así
  que dos partidos de un equipo en días consecutivos son normales.
- **Partidos que faltan (4).** AA Espinho–SL Benfica, Castelo Maia–CA Madalena, Leixões–Sporting CP y
  Vitória SC–Ala N'Alvares. El archivo `226_Hom16 AA Espinho vs SL Benfica` es en realidad una copia
  de Vitória SC–AA Espinho (marcada `es_principal = False`).
- **Un partido de Sporting con local/visitante invertido.** El analista de Sporting nombra sus
  archivos "SCP vs …" y pone a Sporting como local. Sporting–AAS Mamede aparece dos veces (22/11 y
  01/02) y falta AAS Mamede–Sporting: uno de los dos se jugó en la cancha de AAS Mamede, pero los
  datos no permiten saber cuál. En el resto de los archivos de Sporting no hay forma de comprobarlo
  (Sporting figura 12 veces como local, una más que las 11 posibles).
- **Datos personales eliminados.** Un scouter había escrito su teléfono junto al nombre en 7
  archivos; el conversor lo quita del campo `scouter`.
- **Fase.** `competicion_original` dice "1ª Fase" en todos los archivos. `fase_original` dice
  "Home - 1ª Fase", salvo un archivo con "2ª Fase" (error) y 13 vacíos.
- **2 líneas descartadas** (`errores.csv`) con códigos mal escritos.
- Sin coordenadas: para el análisis espacial, usen `zona_inicio`/`zona_fin`.

## Jugadores para revisar

En `jugadores_unificados.csv` hay 20 filas con `revisar = True`, casi todas de jugadores con dos o
tres números en el mismo equipo (se repiten mucho los números 20, 21 y 22, que parecen usados para
"comodines" en algunos archivos). Faria João aparece en CA Madalena y SC Espinho.
